/*
*	interpretilo2.c - средства для подключения библиотек встроенных функций.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "refal.h"


void interp_aldoni_enkonstruitan (char *nomo, void (*f) (void));
char interp_preni_literon (char *, unsigned int *, LITERO *);
LITERO *interp_preni_linion (char *);


/* ========================================================================== */


extern void interp_eraro (char);
extern LITERO *interp_preni_nomon (LITERO *, LITERO **);
extern char interp_kompari_nomojn (LITERO *, LITERO *);
extern void interp_detrui_funkcion (FUNKCIO *);


/* ========================================================================== */


/*
*	Функция "interp_aldoni_enkonstruitan" определяет встроенную функцию,
*	имеющую записанное в кодировке UTF-8 имя "nomo" и связанную со значением
*	аргумента "f".
*
*/

void
interp_aldoni_enkonstruitan (char *nomo, void (*f) (void))
{
	char i = 0;
	LITERO *nomo1;
	FUNKCIO *funk;

	nomo1 = interp_preni_linion (nomo);
	funk = LF;
	do
	{
		funk = funk->sekv;
		i = interp_kompari_nomojn (nomo1, funk->nom);
	}
	while (!i && (funk->sekv != NULL));
	if (i)
	{
		interp_detrui_funkcion (funk);
		funk->enk = 1;
		while (nomo1->sekv != NULL)
		{
			nomo1 = nomo1->sekv;
			detrui_literon (nomo1->ant);
		};
		detrui_literon (nomo1);
	}
	else
	{
		funk->sekv = (FUNKCIO *) malloc (sizeof (FUNKCIO));
		if (funk->sekv == NULL)
		{
			exit (EXIT_FAILURE);
		};
		funk = funk->sekv;
		funk->sekv = NULL;
		funk->enk = 1;
		funk->nom = nomo1;
	};
	funk->dat.f = f;
	return;
}


/* ========================================================================== */


/*
*	Функция "interp_preni_literon" считывает из строки "linio" записанную
*	в кодировке UTF-8 начиная с позиции "(*pozicio)" букву
*	и записывает по адресу "lit->dat.cif" её номер в таблице юникода.
*	При этом в качестве нового значения величины "(*pozicio)" устанавливается
*	номер байта, следующего за считанной буквой.
*
*	Если считывание невозможно, возвращается значение 0. Иначе возвращается
*	значение 1.
*
*/

char
interp_preni_literon (char *linio, unsigned int *pozicio, LITERO *lit)
{
	char c, k = 32;

	c = linio[*pozicio];
	(*pozicio)++;
	if (c == 0)
	{
		lit->dat.cif = 0;
		return 0;
	};
	if (!(c >> 7))
	{
		lit->dat.cif = (unsigned int) c;
		return 1;
	};
	if ((c >> 6 == 2) || (c >> 1 == 127))
	{
		interp_eraro (8);
	};
	while (c & k)
	{
		k >>= 1;
	};
	k--;
	lit->dat.cif = (unsigned int) (c & k);
	k = (~k) << 2;
	while (k)
	{
		c = linio[*pozicio];
		(*pozicio)++;
		if (c >> 6 != 2)
		{
			interp_eraro (8);
		};
		lit->dat.cif <<= 6;
		lit->dat.cif |= (unsigned int) (c & 63);
		k <<= 1;
	};
	return 1;
}


/*
*	Функция "interp_preni_linion" перерабатывает записанную в кодировке UTF-8
*	строку "linio" в соответствующую последовательность литер. Возвращаемым
*	значением является указатель на первую литеру из вышеописанной
*	последовательности, либо NULL (если исходная строка пуста).
*	
*/

LITERO
*interp_preni_linion (char *linio)
{
	char i;
	unsigned int pozicio = 0;
	LITERO *kuranta, *unua;

	krei_literon (kuranta);
	i = interp_preni_literon (linio, &pozicio, kuranta);
	if (!i)
	{
		detrui_literon (kuranta);
		return NULL;
	};
	unua = kuranta;
	do
	{
		krei_literon (kuranta->sekv);
		(kuranta->sekv)->ant = kuranta;
		kuranta = kuranta->sekv;
		i = interp_preni_literon (linio, &pozicio, kuranta);
	}
	while (i);
	detrui_literon (kuranta);
	kuranta = kuranta->ant;
	kuranta->sekv = NULL;
	return unua;
}
