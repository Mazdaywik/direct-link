/*
*	interpretilo1.c - подробное определение интерпретатора.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "refal.h"


void interp_aldoni_funkcion (LITERO *);
void interp_aldoni_substituon (LITERO *);
LITERO *interp_preni_nomon (LITERO *, LITERO **);
LITERO *interp_preteriri_spacetojn (LITERO *);
char interp_kompari_nomojn (LITERO *, LITERO *);
LITERO *interp_preni_nombron (LITERO *, LITERO *);
void interp_sercxi_duonagemajn (void);
void interp_detrui_funkcion (FUNKCIO *);


/* ========================================================================== */


extern void interp_eraro (char);


/* ========================================================================== */


/*
*	Функция "interp_aldoni_funkcion" запускает процесс определения функции,
*	имя которой содержится в строке, начинающейся литерой "unua".
*
*/

void
interp_aldoni_funkcion (LITERO *unua)
{
	char i;
	LITERO *kuranta, *nomo;
	FUNKCIO *funk;

	kuranta = unua;
	kuranta = interp_preni_nomon (kuranta, &nomo);
	funk = LF;
	do
	{
		funk = funk->sekv;
		i = interp_kompari_nomojn (funk->nom, nomo);
	}
	while (!i && (funk->sekv != NULL));
	if (i)
	{
		interp_detrui_funkcion (funk);
		while (nomo->sekv != NULL)
		{
			nomo = nomo->sekv;
			detrui_literon (nomo->ant);
		};
		detrui_literon (nomo);
	}
	else
	{
		funk->sekv = (FUNKCIO *) malloc (sizeof (FUNKCIO));
		if (funk->sekv == NULL)
		{
			exit (EXIT_FAILURE);
		};
		funk = funk->sekv;
		funk->nom = nomo;
		funk->sekv = NULL;
	};
	funk->enk = 0;
	krei_literon (funk->dat.s);
	KFS = funk->dat.s;
	KFS->dat.ref = NULL;
	kuranta = interp_preteriri_spacetojn (kuranta);
	if (kuranta == NULL)
	{
		interp_eraro (10);
	};
	interp_aldoni_substituon (kuranta);
	return;
}


/*
*	Макрос "METI_VAR_ANT" создаёт внутри образца переменную,
*	'активным' вариантом типа которой является значение аргумента "x",
*	а 'пассивным' - значение аргумента "y".
*
*/

# define METI_VAR_ANT(x,y) {\
		lastav->tip = x;\
		if (lit1 == NULL)\
		{\
			interp_eraro (9);\
		};\
		if (lit1->dat.cif != 46)\
		{\
			interp_eraro (9);\
		};\
		detrui_literon (lit);\
		lit = lit1->sekv;\
		detrui_literon (lit1);\
		lit1 = interp_preni_nomon (lit, &(lastav->dat.ref));\
		kurantav = unuav;\
		i = 0;\
		do\
		{\
			if (ESTAS_S_MALAGEM (kurantav)\
				|| ESTAS_T_MALAGEM (kurantav)\
				|| ESTAS_E_MALAGEM (kurantav))\
			{\
				i = 0;\
			}\
			else\
			{\
				i = interp_kompari_nomojn (kurantav->dat.ref,\
					lastav->dat.ref);\
			};\
			if (!i)\
			{\
				kurantav = kurantav->sekv;\
			};\
		}\
		while (!i);\
		if (kurantav != lastav)\
		{\
			if (kurantav->tip != x)\
			{\
				interp_eraro (11);\
			};\
			lastav->tip = y;\
			kuranta1 = lastav->dat.ref;\
			lastav->dat.ref = kurantav;\
			while (kuranta1->sekv != NULL)\
			{\
				kuranta1 = kuranta1->sekv;\
				detrui_literon (kuranta1->ant);\
			};\
			detrui_literon (kuranta1);\
		};\
		kuranta->tip = VAR;\
		kuranta->dat.ref = lastav;\
		krei_literon (kuranta->sekv);\
		(kuranta->sekv)->ant = kuranta;\
		kuranta = kuranta->sekv;\
		krei_literon (lastav->sekv);\
		(lastav->sekv)->ant = lastav;\
		lastav = lastav->sekv;\
		lit = interp_preteriri_spacetojn (lit1);\
	}


/*
*	Макрос "METI_VAR_SEKV" создаёт внутри правой части формулы подстановки
*	переменную, 'активным' вариантом типа которой является значение
*	аргумента "x", а 'пассивным' - значение аргумента "y". Значениями
*	аргументов "z" и "w" являются 'пассивные' варианты прочих двух
*	типов переменных.
*
*/

# define METI_VAR_SEKV(x,y,z,w) {\
		if (lit1 == NULL)\
		{\
			interp_eraro (9);\
		};\
		if (lit1->dat.cif != 46)\
		{\
			interp_eraro (9);\
		};\
		detrui_literon (lit);\
		lit = lit1->sekv;\
		detrui_literon (lit1);\
		kuranta->tip = VAR;\
		krei_literon (kuranta1);\
		kuranta->dat.ref = kuranta1;\
		lit1 = interp_preni_nomon (lit, &(kuranta1->dat.ref));\
		if (lastav == unuav)\
		{\
			interp_eraro (12);\
		};\
		kurantav = lastav->ant;\
		i = 0;\
		do\
		{\
			switch (kurantav->tip)\
			{\
			case z:\
			case w:\
				i = 0;\
				break;\
			case y:\
				if (kurantav->sekv == NULL)\
				{\
					i = 0;\
				}\
				else\
				{\
					i = interp_kompari_nomojn (kuranta1->dat.ref,\
						(kurantav->dat.ref)->dat.ref);\
				};\
				if (i)\
				{\
					kuranta1->tip = y;\
					while ((kuranta1->dat.ref)->sekv != NULL)\
					{\
						kuranta1->dat.ref = (kuranta1->dat.ref)->sekv;\
						detrui_literon ((kuranta1->dat.ref)->ant);\
					};\
					detrui_literon (kuranta1->dat.ref);\
					kuranta1->dat.ref = kurantav;\
					kurantav->sekv = NULL;\
				};\
				break;\
			case S_AGEM:\
			case T_AGEM:\
			case E_AGEM:\
				i = interp_kompari_nomojn (kuranta1->dat.ref,\
					kurantav->dat.ref);\
				if (i)\
				{\
					if (kurantav->tip != x)\
					{\
						interp_eraro (11);\
					};\
					while ((kuranta1->dat.ref)->sekv != NULL)\
					{\
						kuranta1->dat.ref = (kuranta1->dat.ref)->sekv;\
						detrui_literon ((kuranta1->dat.ref)->ant);\
					};\
					detrui_literon (kuranta1->dat.ref);\
					if (kurantav->sekv == NULL)\
					{\
						kuranta1->tip = x;\
						kuranta1->dat.ref = kurantav;\
					}\
					else\
					{\
						kuranta1->tip = y;\
						kuranta1->dat.ref = kurantav;\
						kurantav->sekv = NULL;\
					};\
				};\
				break;\
			};\
			if (!i)\
			{\
				if (kurantav == unuav)\
				{\
					interp_eraro (12);\
				}\
				else\
				{\
					kurantav = kurantav->ant;\
				};\
			};\
		}\
		while (!i);\
		krei_literon (kuranta->sekv);\
		(kuranta->sekv)->ant = kuranta;\
		kuranta = kuranta->sekv;\
		lit = interp_preteriri_spacetojn (lit1);\
	}


/*
*	Функция "interp_aldoni_substituon" добавляет по адресу KFS
*	формулу подстановки, описанную в строке, начинающейся литерой "unua".
*	
*/

void
interp_aldoni_substituon (LITERO *unua)
{
	char i, j = 1;
	signed int parnum = 0;
	LITERO *kuranta, *kuranta1, *lit, *lit1;
	LITERO *unuav, *lastav, *kurantav;
	FUNKCIO *funk;

	lit = unua;
	krei_literon (unuav);
	lastav = unuav;
	krei_literon (kuranta);
	krei_literon (kuranta->ant);
	(kuranta->ant)->sekv = kuranta;
	(kuranta->ant)->tip = MD_FUNK_PARENT;
	KFS->ant = kuranta->ant;
	do
	{
		if (lit == NULL)
		{
			interp_eraro (10);
		}
		else
		{
			lit1 = lit->sekv;
			switch (lit->dat.cif)
			{
/* ( */		case 40:
				parnum++;
				kuranta->tip = MD_STR_PARENT;
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* ) */		case 41:
				parnum--;
				kuranta->tip = D_STR_PARENT;
				kuranta1 = kuranta;
				i = 1;
				do
				{
					kuranta1 = kuranta1->ant;
					switch (kuranta1->tip)
					{
					case MD_LIT_PARENT:
					case MD_FUNK_PARENT:
						interp_eraro (3);
						break;

					case D_LIT_PARENT:
					case D_STR_PARENT:
						kuranta1 = kuranta1->dat.ref;
						break;

					case MD_STR_PARENT:
						i = 0;
						break;
					};
				}
				while (i);
				ligi_parentezojn (kuranta1, kuranta);
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* s */		case 115:
				METI_VAR_ANT (S_AGEM, S_MALAGEM);
				break;

/* t */		case 116:
				METI_VAR_ANT (T_AGEM, T_MALAGEM);
				break;

/* e */		case 101:
				METI_VAR_ANT (E_AGEM, E_MALAGEM);
				break;

/* 0-9 */		case 48:
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
			case 56:
			case 57:
				kuranta->tip = MD_LIT_PARENT;
				krei_literon (kuranta1);
				ligi_literojn (kuranta, kuranta1);
				kuranta1->tip = CIFER;
				kuranta1->dat.cif = lit->dat.cif - 48;
				krei_literon (kuranta);
				ligi_literojn (kuranta1, kuranta);
				kuranta->tip = D_LIT_PARENT;
				ligi_parentezojn (kuranta1->ant, kuranta);
				lit1 = interp_preni_nombron (lit1, kuranta1);
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* ' */		case 39:
				if (lit1 == NULL)
				{
					interp_eraro (10);
				};
				detrui_literon (kuranta);
				ligi_literojn (kuranta->ant, lit1);
				kuranta = lit1;
				i = 1;
				while (i)
				{
					if ((kuranta->dat.cif == 39)
						|| (kuranta->sekv == NULL))
					{
						i = 0;
					}
					else
					{
						kuranta->tip = CIFER;
						krei_literon (kuranta1);
						kuranta1->tip = MD_LIT_PARENT;
						ligi_literojn (kuranta->ant, kuranta1);
						ligi_literojn (kuranta1, kuranta);
						krei_literon (kuranta1);
						kuranta1->tip = D_LIT_PARENT;
						ligi_literojn (kuranta1, kuranta->sekv);
						ligi_literojn (kuranta, kuranta1);
						ligi_parentezojn (kuranta->ant, kuranta1);
						kuranta = kuranta1->sekv;
					};
				};
				if (kuranta->dat.cif != 39)
				{
					interp_eraro (10);
				};
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (kuranta->sekv);
				break;

/* = */		case 61:
				if (parnum != 0)
				{
					interp_eraro (4);
				};
				kuranta->tip = D_FUNK_PARENT;
				ligi_parentezojn (KFS->ant, kuranta);
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				j = 0;
				break;

			default:
				interp_eraro (10);
				break;
			};
		};
	}
	while (j);
	j = 1;
	krei_literon (kuranta);
	kuranta->ant = NULL;
	KFS->sekv = kuranta;
	do
	{
		if (lit == NULL)
		{
			if (parnum != 0)
			{
				interp_eraro (4);
			};
			if (kuranta->ant == NULL)
			{
				KFS->sekv = NULL;
			}
			else
			{
				(kuranta->ant)->sekv = NULL;
			};
			detrui_literon (kuranta);
			j = 0;
		}
		else
		{
			lit1 = lit->sekv;
			switch (lit->dat.cif)
			{
/* ( */		case 40:
				parnum++;
				kuranta->tip = MD_STR_PARENT;
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* ) */		case 41:
				parnum--;
				kuranta->tip = D_STR_PARENT;
				kuranta1 = kuranta;
				i = 1;
				do
				{
					kuranta1 = kuranta1->ant;
					if (kuranta1 == NULL)
					{
						interp_eraro (3);
					};
					switch (kuranta1->tip)
					{
					case MD_LIT_PARENT:
					case MD_FUNK_PARENT:
						interp_eraro (3);
						break;

					case D_LIT_PARENT:
					case D_STR_PARENT:
					case D_FUNK_PARENT:
						kuranta1 = kuranta1->dat.ref;
						break;

					case MD_STR_PARENT:
						i = 0;
						break;
					};
				}
				while (i);
				ligi_parentezojn (kuranta1, kuranta);
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* < */		case 60:
				parnum++;
				lit1 = interp_preni_nomon (lit1, &kuranta1);
				funk = LF;
				do
				{
					funk = funk->sekv;
					i = interp_kompari_nomojn (funk->nom, kuranta1);
				}
				while (!i && (funk->sekv != NULL));
				if (i)
				{
					while (kuranta1->sekv != NULL)
					{
						kuranta1 = kuranta1->sekv;
						detrui_literon (kuranta1->ant);
					};
					detrui_literon (kuranta1);
				}
				else
				{
					funk->sekv = (FUNKCIO *) malloc (sizeof (FUNKCIO));
					if (funk->sekv == NULL)
					{
						exit (EXIT_FAILURE);
					};
					funk = funk->sekv;
					funk->nom = kuranta1;
					funk->sekv = NULL;
					funk->enk = 0;
					funk->dat.s = NULL;
				};
				kuranta->tip = MD_FUNK_PARENT;
				kuranta->dat.funk = funk;
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* > */		case 62:
				parnum--;
				kuranta->tip = D_FUNK_PARENT;
				kuranta1 = kuranta;
				i = 1;
				do
				{
					if (kuranta1->ant == NULL)
					{
						interp_eraro (5);
					};
					kuranta1 = kuranta1->ant;
					switch (kuranta1->tip)
					{
					case MD_LIT_PARENT:
					case MD_STR_PARENT:
						interp_eraro (5);
						break;
	
					case D_LIT_PARENT:
					case D_STR_PARENT:
					case D_FUNK_PARENT:
						kuranta1 = kuranta1->dat.ref;
						break;
	
					case MD_FUNK_PARENT:
						i = 0;
						break;
					};
				}
				while (i);
				kuranta->dat.ref = kuranta1;
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				detrui_literon (lit);
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* s */		case 115:
				METI_VAR_SEKV (S_AGEM, S_MALAGEM, T_MALAGEM, E_MALAGEM);
				break;

/* t */		case 116:
				METI_VAR_SEKV (T_AGEM, T_MALAGEM, S_MALAGEM, E_MALAGEM);
				break;

/* e */		case 101:
				METI_VAR_SEKV (E_AGEM, E_MALAGEM, S_MALAGEM, T_MALAGEM);
				break;

/* 0-9 */		case 48:
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
			case 56:
			case 57:
				kuranta->tip = MD_LIT_PARENT;
				krei_literon (kuranta1);
				ligi_literojn (kuranta, kuranta1);
				kuranta1->tip = CIFER;
				kuranta1->dat.cif = lit->dat.cif - 48;
				krei_literon (kuranta);
				ligi_literojn (kuranta1, kuranta);
				kuranta->tip = D_LIT_PARENT;
				ligi_parentezojn (kuranta1->ant, kuranta);
				detrui_literon (lit);
				lit1 = interp_preni_nombron (lit1, kuranta1);
				krei_literon (kuranta->sekv);
				(kuranta->sekv)->ant = kuranta;
				kuranta = kuranta->sekv;
				lit = interp_preteriri_spacetojn (lit1);
				break;

/* ' */		case 39:
				if (lit1 == NULL)
				{
					interp_eraro (10);
				};
				detrui_literon (lit);
				if (KFS->sekv == kuranta)
				{
					detrui_literon (kuranta);
					lit1->ant = NULL;
					KFS->sekv = lit1;
				}
				else
				{
					detrui_literon (kuranta);
					ligi_literojn (kuranta->ant, lit1);
				};
				kuranta = lit1;
				i = 1;
				while (i)
				{
					if ((kuranta->dat.cif == 39)
						|| (kuranta->sekv == NULL))
					{
						i = 0;
					}
					else
					{
						kuranta->tip = CIFER;
						krei_literon (kuranta1);
						kuranta1->tip = MD_LIT_PARENT;
						if (kuranta->ant == NULL)
						{
							kuranta1->ant = NULL;
							KFS->sekv = kuranta1;
						}
						else
						{
							ligi_literojn (kuranta->ant, kuranta1);
						};
						ligi_literojn (kuranta1, kuranta);
						krei_literon (kuranta1);
						kuranta1->tip = D_LIT_PARENT;
						ligi_literojn (kuranta1, kuranta->sekv);
						ligi_literojn (kuranta, kuranta1);
						ligi_parentezojn (kuranta->ant, kuranta1);
						kuranta = kuranta1->sekv;
					};
				};
				if (kuranta->dat.cif != 39)
				{
					interp_eraro (10);
				};
				lit = interp_preteriri_spacetojn (kuranta->sekv);
				break;

			default:
				interp_eraro (10);
				break;
			};
		};
	}
	while (j);
	kurantav = lastav;
	while (kurantav != unuav)
	{
		kurantav = kurantav->ant;
		if (ESTAS_S_AGEM (kurantav) || ESTAS_T_AGEM (kurantav)
			|| ESTAS_E_AGEM (kurantav))
		{
			kuranta = kurantav->dat.ref;
			while (kuranta->sekv != NULL)
			{
				kuranta = kuranta->sekv;
				detrui_literon (kuranta->ant);
			};
			detrui_literon (kuranta);
		};
	};
	detrui_literon (lastav);
	interp_sercxi_duonagemajn ();
	return;
}


/* ========================================================================== */


/*
*	Функция "interp_preni_nomon" выделяет из строки с началом "unua" имя,
*	расположенное в начале этой строки. Последняя литера имени при этом
*	'отрывается' от следующей за ней литеры. Указателю "*nomo" присваивается
*	значение "unua".
*
*	Возвращаемым значением является указатель на литеру, в изначальной строке
*	следовавшую за последней литерой выделенного имени (либо NULL, если
*	последняя литера имени была и последней литерой строки).
*	
*	Буквы, допустимые в качестве составляющих имени, представляют собой
*	NameStartChar из стандарта XML1.1, а также цифры "0" - "9".
*
*/

LITERO
*interp_preni_nomon (LITERO *unua, LITERO **nomo)
{
	char i = 1;
	unsigned int c;
	LITERO *kuranta;

	(*nomo) = unua;
	kuranta = unua;
	if (kuranta == NULL)
	{
		interp_eraro (9);
	};
	do
	{
		if (kuranta == NULL)
		{
			i = 0;
		}
		else
		{
			c = kuranta->dat.cif;
			if (((c > 47) && (c < 59)) || ((c > 64) && (c < 91)) || (c == 95)
				|| ((c > 96) && (c < 123)) || ((c > 191) && (c < 215))
				|| ((c > 215) && (c < 247)) || ((c > 247) && (c < 768))
				|| ((c > 879) && (c < 894)) || ((c > 894) && (c < 8192))
				|| (c == 8204) || (c == 8205) || ((c > 8303) && (c < 8592))
				|| ((c > 11263) && (c < 12272))
				|| ((c > 12288) && (c < 55296))
				|| ((c > 63743) && (c < 64976))
				|| ((c > 65007) && (c < 65534))
				|| ((c > 65535) && (c < 983038)))
			{
				kuranta = kuranta->sekv;
			}
			else
			{
				if (kuranta == unua)
				{
					interp_eraro (9);
				};
				(kuranta->ant)->sekv = NULL;
				i = 0;
			};
		};
	}
	while (i);
	return kuranta;
}


/*
*	Функция "interp_preteriri_spacetojn" возвращает указатель на ближайшую
*	справа к литере "unua" литеру, значение которой отлично от пробела
*	и символа табуляции. Если значение литеры "unua" не являлось
*	пробелом или символом табуляции, возвращается сама эта литера.
*
*	Если справа от "unua" нет литер, значение которых отлично от пробела
*	или символа табуляции, возвращаемым значением является NULL. Если
*	значением аргумента "unua" является NULL, возвращаемым значением
*	также является NULL.
*
*	Если возвращаемое значение отлично от аргумента "unua", то все литеры,
*	заключённые между "unua" и возвращаемой (включая "unua"), удаляются.
*
*/

LITERO
*interp_preteriri_spacetojn (LITERO *unua)
{
	LITERO *kuranta;

	kuranta = unua;
	if (kuranta == NULL)
	{
		return NULL;
	};
	while (1)
	{
		if ((kuranta->dat.cif == 9) || (kuranta->dat.cif == 32))
		{
			if (kuranta->sekv == NULL)
			{
				detrui_literon (kuranta);
				return NULL;
			};
			kuranta = kuranta->sekv;
			detrui_literon (kuranta->ant);
		}
		else
		{
			return kuranta;
		};
	};
	return NULL;
}


/*
*	Функция "interp_kompari_nomojn" сравнивает имена "nom1" и "nom2".
*	Если имена равны, возвращаемым значением функции является 1.
*	Иначе таковым является 0.
*
*/

char
interp_kompari_nomojn (LITERO *nom1, LITERO *nom2)
{
	char i = 1;
	LITERO *kuranta1, *kuranta2;

	kuranta1 = nom1;
	kuranta2 = nom2;
	do
	{
		if (kuranta1->dat.cif == kuranta2->dat.cif)
		{
			kuranta1 = kuranta1->sekv;
			kuranta2 = kuranta2->sekv;
		}
		else
		{
			i = 0;
		};
	}
	while (i && (kuranta1 != NULL) && (kuranta2 != NULL));
	if (i)
	{
		if ((kuranta1 != NULL) || (kuranta2 != NULL))
		{
			return 0;
		}
		else
		{
			return 1;
		};
	}
	else
	{
		return 0;
	};
}


/*
*	Функция "interp_preni_nombron" считывает число, чья вторая (!) цифра
*	записана в начале строки с первой литерой "unua". Считанное число
*	записывается между левой литероидной скобкой "lasta->ant"
*	и соответствующей правой скобкой. При этом предполагается, что
*	перед началом работы функции первая цифра считываемого числа уже записана
*	по адресу "lasta->dat.cif".
*	
*	Возвращаемым значением функции является указатель на первую литеру
*	после считанного числа (либо NULL, если после считанного числа нет литер).
*	При этом литеры, отвечающие считанному числу, удаляются.
*
*/

LITERO
*interp_preni_nombron (LITERO *unua, LITERO *lasta)
{
	char i = 1;
	unsigned long long k;
	LITERO *kuranta, *kuranta1;

	kuranta = unua;
	do
	{
		if (kuranta == NULL)
		{
			i = 0;
		}
		else
		{
			if ((kuranta->dat.cif > 47) && (kuranta->dat.cif < 58))
			{
				kuranta1 = lasta;
				k = ((unsigned long long) (kuranta1->dat.cif)) * 10 +
					kuranta->dat.cif - 48;
				kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
				k /= 4294967296ULL;
				kuranta1 = kuranta1->sekv;
				while (ESTAS_CIFER (kuranta1))
				{
					k += ((unsigned long long) (kuranta1->dat.cif)) * 10;
					kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
					k /= 4294967296ULL;
					kuranta1 = kuranta1->sekv;
				};
				if (k != 0)
				{
					krei_literon ((kuranta1->ant)->sekv);
					((kuranta1->ant)->sekv)->ant = kuranta1->ant;
					ligi_literojn ((kuranta1->ant)->sekv, kuranta1);
					(kuranta1->ant)->tip = CIFER;
					(kuranta1->ant)->dat.cif = (unsigned int) k;
				};
				kuranta1 = kuranta->sekv;
				detrui_literon (kuranta);
				kuranta = kuranta1;
			}
			else
			{
				i = 0;
			};
		};
	}
	while (i);
	return kuranta;
}


/*
*	Функция "interp_sercxi_duonagemajn" выделяет в образце "KFS->ant"
*	'полуактивные' e-переменные и связывает 'активные' e-переменные в список.
*
*/

void
interp_sercxi_duonagemajn ()
{
	char i;
	LITERO *kuranta, *kuranta1, *aev = NULL;

	kuranta = KFS->ant;
	while (!ESTAS_D_FUNK_PARENT (kuranta))
	{
		switch (kuranta->tip)
		{
		case MD_LIT_PARENT:
			kuranta = kuranta->dat.ref;
			break;

		case MD_STR_PARENT:
		case MD_FUNK_PARENT:
			kuranta1 = kuranta->dat.ref;
			i = 1;
			while (i)
			{
				kuranta1 = kuranta1->ant;
				switch (kuranta1->tip)
				{
				case D_LIT_PARENT:
				case D_STR_PARENT:
					kuranta1 = kuranta1->dat.ref;
					break;

				case MD_STR_PARENT:
				case MD_FUNK_PARENT:
					i = 0;
					break;

				case VAR:
					switch ((kuranta1->dat.ref)->tip)
					{
					case E_AGEM:
						(kuranta1->dat.ref)->tip = E_DUONAGEM;
						i = 0;
						break;

					case E_MALAGEM:
						i = 0;
						break;
					
					default:
						break;
					};
					break;
				};
			};
			break;
		
		case VAR:
			kuranta1 = kuranta->dat.ref;
			if (ESTAS_E_AGEM (kuranta1))
			{
				kuranta1->dat.ref = aev;
				aev = kuranta;
			};
			break;
		
		default:
			break;
		};
		kuranta = kuranta->sekv;
	};
	return;
}


/*
*	Функция "interp_detrui_funkcion" освобождает память, использованную
*	при описании функции "funk".
*
*/

void
interp_detrui_funkcion (FUNKCIO *funk)
{
	LITERO *kuranta_l, *sekva_l, *kuranta_s, *sekva_s;

	if (funk->enk)
	{
		return;
	};
	if (funk->dat.s != NULL)
	{
		kuranta_s = funk->dat.s;
		funk->dat.s = NULL;
		do
		{
			sekva_s = kuranta_s->dat.ref;
			if (kuranta_s->ant != NULL)
			{
				kuranta_l = kuranta_s->ant;
				while (!ESTAS_D_FUNK_PARENT (kuranta_l))
				{
					sekva_l = kuranta_l->sekv;
					if (ESTAS_VAR (kuranta_l))
					{
						detrui_literon (kuranta_l->dat.ref);
					};
					detrui_literon (kuranta_l);
					kuranta_l = sekva_l;
				};
				detrui_literon (kuranta_l);
			};
			if (kuranta_s->sekv != NULL)
			{
				kuranta_l = kuranta_s->sekv;
				while (kuranta_l != NULL)
				{
					sekva_l = kuranta_l->sekv;
					if (ESTAS_VAR (kuranta_l))
					{
						detrui_literon (kuranta_l->dat.ref);
					};
					detrui_literon (kuranta_l);
					kuranta_l = sekva_l;
				};
			};
			detrui_literon (kuranta_s);
			kuranta_s = sekva_s;
		}
		while (kuranta_s != NULL);
	};
	return;
}
