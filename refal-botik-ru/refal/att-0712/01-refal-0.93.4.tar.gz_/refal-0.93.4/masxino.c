/*
*	masxino.c - наиболее общие функции рефал-машины.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "refal.h"
# include <libintl.h>


void ref_lancxi (void);
void ref_cxesigi (void);
void ref_eraro (char);


void ref_forfroti (void);
char ref_konkretigi (void);
char *ref_skribi_nomon (void);


/* ========================================================================== */


extern char ref_alfronti (void);
extern void ref_substitui (void);


/* ========================================================================== */


/*
*	Функция "ref_lancxi" осуществляет цикл из шагов рефал-машины.
*
*/

void
ref_lancxi ()
{
	char i;
	LITERO *LKPmn;

	do
	{
		KKP = LKP->dat.ref;
		KKK = KKP->dat.ref;
		i = ref_konkretigi ();
		ref_forfroti ();
		LKPmn = LKP;
		LKP = LKP->sekv;
		detrui_literon (LKPmn);
	}
	while (i);
	return;
}


/*
*	Функция "ref_cxesigi" представляет собой пустую функцию, используемую
*	в процессе остановки рефал-машины.
*
*/

void
ref_cxesigi ()
{

	return;
}


/*
*	Функция "ref_eraro" генерирует сообщения об ошибках работы рефал-машины.
*
*/

void
ref_eraro (char ern)
{
	char *nomo;

	nomo = ref_skribi_nomon ();
	fprintf (stderr, "\n%s \"%s\": ", gettext ("Funkcio"), nomo);
	switch (ern)
	{
	case 1:
		fprintf (stderr, "%s.\n",
			gettext ("alfrontado estas neebla"));
		break;

	case 2:
		fprintf (stderr, "%s.\n",
			gettext ("apliko je sendeterminita funkcio"));
		break;

	default:
		fprintf (stderr, "%s.\n", gettext ("nerekonita eraro"));
		break;
	};
	exit (EXIT_FAILURE);
	return;
}


/* ========================================================================== */


/*
*	Функция "ref_forfroti" удаляет функциональные скобки, отвечающие
*	уже осуществлённой конкретизации.
*
*/

void
ref_forfroti ()
{

	if (KKK->sekv == KKP)
	{
		ligi_literojn (KKK->ant, KKP->sekv);
	}
	else
	{
		ligi_literojn (KKK->ant, KKK->sekv);
		ligi_literojn (KKP->ant, KKP->sekv);
	};
	detrui_literon (KKP);
	detrui_literon (KKK);
	return;
}


/*
*	Функция "ref_konkretigi" осуществляет процесс конкретизации. Если
*	текущий шаг является последним, то возвращается значение 0. В противном
*	случае возвращается значение 1.
*
*/

char
ref_konkretigi ()
{
	char i, j = 1;

	if ((KKK->dat.funk)->enk)
	{
		(*((KKK->dat.funk)->dat.f)) ();
	}
	else
	{
		KFS = (KKK->dat.funk)->dat.s;
		if (KFS == NULL)
		{
			ref_eraro (2);
		};
		while (j)
		{
			i = ref_alfronti ();
			if (i)
			{
				ref_substitui ();
				j = 0;
			}
			else
			{
				if (KFS->dat.ref == NULL)
				{
					ref_eraro (1);
				};
				KFS = KFS->dat.ref;
			};
		};
	};
	if (KKK->dat.funk == LF)
	{
		return 0;
	}
	else
	{
		return 1;
	};
}


/*
*	Функция "ref_skribi_nomon" возвращает строку (в кодировке UTF-8),
*	содержащую имя функции "KKK->dat.funk".
*
*/

char
*ref_skribi_nomon ()
{
	char i, *nomo;
	unsigned int k = 1, c = 0;
	LITERO *kuranta;

	kuranta = (KKK->dat.funk)->nom;
	while (kuranta != NULL)
	{
		c = kuranta->dat.cif;
		kuranta = kuranta->sekv;
		k++;
		if (c >> 7)
		{
			k++;
			if (c >> 11)
			{
				k++;
				if (c >> 16)
				{
					k++;
					if (c >> 21)
					{
						k++;
						if (c >> 26)
						{
							k++;
						};
					};
				};
			};
		};
	};
	nomo = (char *) malloc (sizeof (char) * k);
	if (nomo == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = (KKK->dat.funk)->nom;
	k = 0;
	while (kuranta != NULL)
	{
		i = 0;
		c = kuranta->dat.cif;
		if (!(c >> 7))
		{
			nomo[k] = (char) c;
			k++;
			i = 1;
		};
		if ((i == 0) && !(c >> 11))
		{
			nomo[k] = (char) ((c >> 6) | 192);
			c <<= 26;
			k++;
			i = 2;
		};
		if ((i == 0) && !(c >> 16))
		{
			nomo[k] = (char) ((c >> 12) | 224);
			c <<= 20;
			k++;
			i = 3;
		};
		if ((i == 0) && !(c >> 21))
		{
			nomo[k] = (char) ((c >> 18) | 240);
			c <<= 14;
			k++;
			i = 4;
		};
		if ((i == 0) && !(c >> 26))
		{
			nomo[k] = (char) ((c >> 24) | 248);
			c <<= 8;
			k++;
			i = 5;
		};
		if (i == 0)
		{
			nomo[k] = (char) ((c >> 30) | 252);
			c <<= 2;
			k++;
			i = 6;
		};
		while (i != 1)
		{
			nomo[k] = (char) ((c >> 26) | 128);
			c <<= 6;
			k++;
			i--;
		};
		kuranta = kuranta->sekv;
	};
	nomo[k] = 0;
	return nomo;
}
