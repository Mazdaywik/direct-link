/*
*	masxino1.c - подробное описание рефал-машины.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "refal.h"


/*
*	Значениями переменных "al[0]" и "al[1]" являются указатели
*	на сопоставляемые в текущий момент литеры поля зрения и образца,
*	соответственно. Значением переменной "aev" является указатель
*	на ближайшую слева к "al[1]" активную e-переменную (либо равен NULL).
*
*/

LITERO *al[2], *aev;

char ref_alfronti (void);
void ref_substitui (void);


char ref_retirigxi (void);
char ref_kompari (LITERO *);
LITERO *ref_kopii (LITERO *, LITERO *, LITERO *);
void ref_stringi (void);
void ref_klarigi (void);


/* ========================================================================== */

extern void ref_eraro (char);


/* ========================================================================== */


/*
*	Функция "ref_alfronti" сопоставляет выражение, заключённое между "KKK"
*	и "KKP", с образцом, заключённым между "KFS->ant" и "(KFS->ant)->dat.ref".
*	
*	В случае возможности сопоставления возвращаемым значением функции
*	является 1. При этом значениями полей "->ant" и "->sekv" в отвечающих
*	сопоставленному образцу описаниях переменных оказываются такие,
*	которые соответствуют 'самому левому' варианту сопоставления.
*
*	В случае невозможности сопоставления возвращаемым значением является 0.
*	
*/

char
ref_alfronti ()
{
	char i;
	LITERO *kuranta, *v;

	al[0] = KKK->sekv;
	al[1] = (KFS->ant)->sekv;
	aev = NULL;
	while (1)
	{
		switch ((al[1])->tip)
		{
		case CIFER:
			if (ESTAS_CIFER (al[0]))
			{
				if ((al[0])->dat.cif == (al[1])->dat.cif)
				{
					al[0] = (al[0])->sekv;
					al[1] = (al[1])->sekv;
				}
				else
				{
					i = ref_retirigxi ();
					if (!i)
					{
						return 0;
					};
				};
			}
			else
			{
				i = ref_retirigxi ();
				if (!i)
				{
					return 0;
				};
			};
			break;

		case MD_LIT_PARENT:
		case D_LIT_PARENT:
		case MD_STR_PARENT:
		case D_STR_PARENT:
			if ((al[0])->tip == (al[1])->tip)
			{
				al[0] = (al[0])->sekv;
				al[1] = (al[1])->sekv;
			}
			else
			{
				i = ref_retirigxi ();
				if (!i)
				{
					return 0;
				};
			};
			break;

		case D_FUNK_PARENT:
			if (al[0] == KKP)
			{
				return 1;
			}
			else
			{
				i = ref_retirigxi ();
				if (!i)
				{
					return 0;
				};
			};
			break;

		case VAR:
			v = (al[1])->dat.ref;
			switch (v->tip)
			{
			case S_MALAGEM:
			case T_MALAGEM:
			case E_MALAGEM:
				v->ant = (al[0])->ant;
				i = ref_kompari (v->dat.ref);
				if (i)
				{
					v->sekv = al[0];
				}
				else
				{
					i = ref_retirigxi ();
					if (!i)
					{
						return 0;
					};
				};
				break;

			case S_AGEM:
				if (ESTAS_MD_LIT_PARENT (al[0]))
				{
					v->ant = (al[0])->ant;
					v->sekv = ((al[0])->dat.ref)->sekv;
					al[0] = v->sekv;
					al[1] = (al[1])->sekv;
				}
				else
				{
					i = ref_retirigxi ();
					if (!i)
					{
						return 0;
					};
				};
				break;

			case T_AGEM:
				if (ESTAS_MD_LIT_PARENT (al[0])
					|| ESTAS_MD_STR_PARENT (al[0]))
				{
					v->ant = (al[0])->ant;
					v->sekv = ((al[0])->dat.ref)->sekv;
					al[0] = v->sekv;
					al[1] = (al[1])->sekv;
				}
				else
				{
					i = ref_retirigxi ();
					if (!i)
					{
						return 0;
					};
				};
				break;

			case E_AGEM:
				aev = al[1];
				v->ant = (al[0])->ant;
				v->sekv = al[0];
				al[1] = (al[1])->sekv;
				break;

			case E_DUONAGEM:
				al[0] = al[0]->ant;
				v->ant = al[0];
				kuranta = al[1]->ant;
				while (!ESTAS_MD_STR_PARENT (kuranta)
					&& !ESTAS_MD_FUNK_PARENT (kuranta))
				{
					switch (kuranta->tip)
					{
					case D_LIT_PARENT:
					case D_STR_PARENT:
						kuranta = kuranta->dat.ref;
						al[0] = (al[0])->dat.ref;
						break;
						
					case VAR:
						al[0] = ((kuranta->dat.ref)->ant)->sekv;
						break;
						
					default:
						ref_eraro (-1);
						break;
					};
					kuranta = kuranta->ant;
					al[0] = (al[0])->ant;
				};
				kuranta = kuranta->dat.ref;
				if (ESTAS_MD_FUNK_PARENT (al[0]))
				{
					al[0] = KKP;
				}
				else
				{
					al[0] = (al[0])->dat.ref;
				};
				i = 1;
				while (i)
				{
					kuranta = kuranta->ant;
					al[0] = (al[0])->ant;
					switch (kuranta->tip)
					{
					case D_LIT_PARENT:
					case D_STR_PARENT:
						if (((al[0])->tip != kuranta->tip)
							|| (al[0] == v->ant))
						{
							i = ref_retirigxi ();
							if (!i)
							{
								return 0;
							};
							i = 0;
						}
						else
						{
							kuranta = kuranta->dat.ref;
							al[0] = al[0]->dat.ref;
						};
						break;
						
					case VAR:
						if (kuranta == al[1])
						{
							al[0] = (al[0])->sekv;
							al[1] = (al[1])->sekv;
							v->sekv = al[0];
							i = 0;
						}
						else
						{
							if (al[0] == v->ant)
							{
								i = ref_retirigxi ();
								if (!i)
								{
									return 0;
								};
								i = 0;
							}
							else
							{
								al[0] = (al[0])->dat.ref;
							};
						};
						break;
						
					default:
						ref_eraro (-1);
						break;
					};
				};
				break;
			};
			break;
		};
	};
	return 0;
}


/*
*	Функция "ref_substitui" заменяет выражение, заключённое между "KKK" и
*	"KKP", выражением, получаемым в результате подстановки в правую часть
*	"KFS->sekv" соответствующих значений переменных из образца "KFS->ant".
*
*	При этом также заменяется список конкретизаций: если правая часть
*	"KFS->sekv" (а тогда и вставляемое выражение) содержит конкретизации,
*	то указатели на возникающие внутри поля зрения правые функциональные скобки
*	вставляются после текущего LKP.
*	
*	# Указатели "->ant" в литерах из правой части "KFS->sekv" не используются
*	# по прямому назначению. Это позволяет применять их в качестве буфера.
*	# Такая возможность действительно используется в функции "ref_substitui".
*
*/

void
ref_substitui ()
{
	LITERO *bufro, *kuranta_esp, *kuranta_rez, *kuranta_lkp;
	LITERO *unua, *lasta, *v;

	ref_stringi ();
	krei_literon (bufro);
	ligi_literojn (bufro, KKK->sekv);
	bufro->ant = NULL;
	kuranta_esp = KKK;
	kuranta_rez = KFS->sekv;
	kuranta_lkp = LKP;
	while (kuranta_rez != NULL)
	{
		switch (kuranta_rez->tip)
		{
		case CIFER:
			krei_literon (bufro);
			ligi_literojn (kuranta_esp, bufro);
			kuranta_esp = bufro;
			kuranta_esp->tip = CIFER;
			kuranta_esp->dat.cif = kuranta_rez->dat.cif;
			break;

		case MD_LIT_PARENT:
			krei_literon (bufro);
			ligi_literojn (kuranta_esp, bufro);
			kuranta_esp = bufro;
			kuranta_esp->tip = MD_LIT_PARENT;
			krei_literon (bufro);
			bufro->tip = D_LIT_PARENT;
			ligi_parentezojn (kuranta_esp, bufro);
			(kuranta_rez->dat.ref)->ant = bufro;
			break;

		case MD_STR_PARENT:
			krei_literon (bufro);
			ligi_literojn (kuranta_esp, bufro);
			kuranta_esp = bufro;
			kuranta_esp->tip = MD_STR_PARENT;
			krei_literon (bufro);
			bufro->tip = D_STR_PARENT;
			ligi_parentezojn (kuranta_esp, bufro);
			(kuranta_rez->dat.ref)->ant = bufro;
			break;

		case D_LIT_PARENT:
		case D_STR_PARENT:
			ligi_literojn (kuranta_esp, kuranta_rez->ant);
			kuranta_esp = kuranta_esp->sekv;
			break;

		case MD_FUNK_PARENT:
			krei_literon (bufro);
			ligi_literojn (kuranta_esp, bufro);
			kuranta_esp = bufro;
			kuranta_esp->tip = MD_FUNK_PARENT;
			kuranta_esp->dat.funk = kuranta_rez->dat.funk;
			krei_literon (bufro);
			bufro->tip = D_FUNK_PARENT;
			bufro->dat.ref = kuranta_esp;
			kuranta_rez->ant = bufro;
			break;

		case D_FUNK_PARENT:
			ligi_literojn (kuranta_esp, (kuranta_rez->dat.ref)->ant);
			kuranta_esp = kuranta_esp->sekv;
			krei_literon (bufro);
			bufro->sekv = kuranta_lkp->sekv;
			kuranta_lkp->sekv = bufro;
			kuranta_lkp = bufro;
			kuranta_lkp->dat.ref = kuranta_esp;
			break;

		case VAR:
			v = kuranta_rez->dat.ref;
			if ((v->dat.ref)->ant != NULL)
			{
				unua = (v->dat.ref)->ant;
				lasta = (v->dat.ref)->sekv;
				if (ESTAS_S_AGEM (v) || ESTAS_T_AGEM (v)
					|| ESTAS_E_AGEM (v))
				{
					kuranta_esp = ref_kopii (unua, lasta, kuranta_esp);
				}
				else
				{
					ligi_literojn (unua->ant, lasta->sekv);
					ligi_literojn (kuranta_esp, unua);
					kuranta_esp = lasta;
				};
			};
			break;
		};
		kuranta_rez = kuranta_rez->sekv;
	};
	ref_klarigi ();
	ligi_literojn (kuranta_esp, KKP);
	return;
}


/* ========================================================================== */


/*
*	Функция "ref_retirigxi" производит откат к ближайшей слева 'активной'
*	e-переменной, чьё значение может быть удлинено на терм. Начальное
*	состояние процесса отката определяется значением переменной "al[1]".
*	
*	В случае неуспеха процедуры возвращаемым значением функции является 0.
*	В случае успеха процедуры возвращаемым значением является 1, причём:
*	
*	1) Ближайшая слева к начальному состоянию 'активная' e-переменная,
*	допускающая удлинение, удлиняется на терм;
*	2) Значением переменной "al[1]" становится указатель на первую литеру
*	после удлинённой e-переменной;
*	3) Значением переменной "al[0]" становится указатель на первую литеру
*	после нового значения удлинённой e-переменной;
*	4) Значением переменной "aev" становится указатель на ближайшую слева
*	к новому значению переменной "al[1]" активную e-переменную.
*
*/

char
ref_retirigxi ()
{
	LITERO *v;

	while (1)
	{
		if (aev == NULL)
		{
			return 0;
		}
		else
		{
			al[1] = aev;
			v = al[1]->dat.ref;
			if (ESTAS_MD_LIT_PARENT (v->sekv)
				|| ESTAS_MD_STR_PARENT (v->sekv))
			{
				v->sekv = ((v->sekv)->dat.ref)->sekv;
				al[0] = v->sekv;
				al[1] = (al[1])->sekv;
				return 1;
			}
			else
			{
				aev = v->dat.ref;
			};
		};
	};
	return 0;
}


/*
*	Функция "ref_kompari" определяет, является ли значение переменной,
*	имеющей описание "v", началом подвыражения, первой литерой которого
*	является "al[0]".
*
*	В случае неуспеха процедуры возвращаемым значением функции является 0.
*	При этом значение переменной "al[0]" становится, вообще говоря,
*	бессмысленным. В случае успеха процедуры возвращаемым значением
*	является 1, причём:
*	
*	1) Значением переменной "al[1]" становится указатель "(al[1])->sekv";
*	2) Значением переменной "al[0]" становится указатель на первую литеру
*	после вышеописанной копии значения переменной с описанием "v".
*
*/

char
ref_kompari (LITERO *v)
{
	LITERO *kuranta, *lasta;

	kuranta = (v->ant)->sekv;
	lasta = v->sekv;
	while (1)
	{
		if (kuranta == lasta)
		{
			al[1] = (al[1])->sekv;
			return 1;
		};
		if ((al[0])->tip == kuranta->tip)
		{
			if ((al[0])->tip == CIFER)
			{
				if ((al[0])->dat.cif != kuranta->dat.cif)
				{
					return 0;
				};
			};
		}
		else
		{
			return 0;
		}
		kuranta = kuranta->sekv;
		al[0] = (al[0])->sekv;
	};
	return 0;
}


/*
*	Функция "ref_kopii" копирует подвыражение, расположенное между "unua" и
*	"lasta" (включая эти две литеры), и 'приклеивает' копию после "esp".
*	
*	Возвращаемым значением функции является указатель на последнюю литеру
*	'приклеенной' копии.
*
*/

LITERO
*ref_kopii (LITERO *unua, LITERO *lasta, LITERO *esp)
{
	LITERO *kuranta, *vidata;

	vidata = unua;
	kuranta = esp;
	while (1)
	{
		krei_literon (kuranta->sekv);
		(kuranta->sekv)->ant = kuranta;
		kuranta = kuranta->sekv;
		kuranta->tip = vidata->tip;
		switch (kuranta->tip)
		{
		case CIFER:
			kuranta->dat.cif = vidata->dat.cif;
			break;

		case MD_LIT_PARENT:
		case MD_STR_PARENT:
			vidata->dat.ref = kuranta;
			break;

		case D_LIT_PARENT:
		case D_STR_PARENT:
			ligi_parentezojn ((vidata->dat.ref)->dat.ref, kuranta);
			(vidata->dat.ref)->dat.ref = vidata;
			break;
		};
		if (vidata == lasta)
		{
			return kuranta;
		}
		else
		{
			vidata = vidata->sekv;
		};
	};
	return kuranta;
}


/*
*	Функция "ref_stringi" 'сдвигает' значения полей "( ->dat.ref)->ant" и
*	"( ->dat.ref)->sekv" для всех переменных из образца "KFS->ant"
*	на одну позицию 'внутрь' значений переменных. Для e-переменных
*	с пустыми значениями в качестве нового значения поля
*	"( ->dat.ref)->ant" устанавливается NULL.
*
*	# ПРИМЕР: Рассмотрим образец
*	#
*	#		< s.1 ( e.2 ) e.3 >,
*	#
*	# сопоставляемый с выражением
*	#
*	#		< a ( ) b c d >
*	#		1 2 3 4 5 6 7 8.
*	#
*	# Исходными значениями будут:
*	# ('s.1'->dat.ref)->ant = 1,	('s.1'->dat.ref)->sekv = 3,
*	# ('e.2'->dat.ref)->ant = 3,	('e.2'->dat.ref)->sekv = 4,
*	# ('e.3'->dat.ref)->ant = 4,	('e.3'->dat.ref)->sekv = 8.
*	#
*	# Новыми значениями будут:
*	# ('s.1'->dat.ref)->ant = 2,	('s.1'->dat.ref)->sekv = 2,
*	# ('e.2'->dat.ref)->ant = NULL,
*	# ('e.3'->dat.ref)->ant = 5,	('e.3'->dat.ref)->sekv = 7.
*
*/

void
ref_stringi ()
{
	LITERO *kuranta, *v;

	kuranta = KFS->ant;
	while (!ESTAS_D_FUNK_PARENT (kuranta))
	{
		if (ESTAS_VAR (kuranta))
		{
			v = kuranta->dat.ref;
			if ((v->ant)->sekv == v->sekv)
			{
				v->ant = NULL;
			}
			else
			{
				v->ant = (v->ant)->sekv;
				v->sekv = (v->sekv)->ant;
			};
		};
		kuranta = kuranta->sekv;
	};
	return;
}


/*
*	Функция "ref_klarigi" освобождает память из неиспользованных
*	при построении нового поля зрения частей исходного поля зрения.
*
*/

void
ref_klarigi ()
{
	LITERO *kuranta;

	kuranta = KKP->ant;
	while (kuranta != NULL)
	{
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
	};
	return;
}
