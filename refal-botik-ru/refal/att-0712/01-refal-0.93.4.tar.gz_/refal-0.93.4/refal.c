/*
*	refal.c - основная функция представляемой реализации языка Рефал.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "refal.h"
# include <libintl.h>


int ARGC;			/* Первый аргумент основной функции */
char **ARGV;		/* Второй аргумент основной функции */


LITERO *LLL;		/* Начало списка свободных литер */
FUNKCIO *LF;		/* Начало списка функций */
LITERO *LKP;		/* Начало списка конкретизаций */
LITERO *KKK;		/* Текущая левая функциональная скобка */
LITERO *KKP;		/* Текущая правая функциональная скобка */
LITERO *KFS;		/* Текущая формула подстановки */


/* ========================================================================== */


extern void ref_lancxi (void);
extern void ref_cxesigi (void);
extern void interp_krei_masxinon (char *);


/* ========================================================================== */

/*
*	Функция "main" устанавливает начальное состояние рефал-машины:
*	1) Создаётся список функций, содержащий две функции:
*		a) безымянную функцию, останавливающую машину (ниже условно
*		   называемую "$halt");
*		b) функцию "$start", запускающую машину.
*	2) Создаётся поле зрения вида
*		<$halt <$start > >
*		1      2       3 4
*	3) Создаётся список конкретизаций, содержащий указатели на литеры 3 и 4
*	(см. пункт 2). После указателя на правую функциональную скобку 4
*	добавляется дополнительный элемент, не указывающий никуда (но требующийся
*	для корректной работы ряда функций).
*
*	По окончании указанной работы запускается процесс интерпретации файла
*	с именем "argv[1]", а затем - рефал-машина.
*
*/

int
main (int argc, char *argv[])
{
	LITERO *kkh, *kks, *kps, *kph, *kuranta;

	setlocale (LC_ALL, "");
	textdomain ("refal");
	ARGC = argc;
	ARGV = argv;
	LLL = (LITERO *) malloc (sizeof (LITERO));
	LF = (FUNKCIO *) malloc (sizeof (FUNKCIO));
	if ((LLL == NULL) || (LF == NULL))
	{
		exit (EXIT_FAILURE);
	};
	LLL->sekv = NULL;
	LF->enk = 1;
	LF->dat.f = ref_cxesigi;
	LF->sekv = (FUNKCIO *) malloc (sizeof (FUNKCIO));
	if (LF->sekv == NULL)
	{
		exit (EXIT_FAILURE);
	};
	(LF->sekv)->enk = 0;
	(LF->sekv)->dat.s = NULL;
	krei_literon ((LF->sekv)->nom);
	kuranta = (LF->sekv)->nom;
	kuranta->dat.cif = 36;
	krei_literon (kuranta->sekv);
	(kuranta->sekv)->ant = kuranta;
	kuranta = kuranta->sekv;
	kuranta->dat.cif = 115;
	krei_literon (kuranta->sekv);
	(kuranta->sekv)->ant = kuranta;
	kuranta = kuranta->sekv;
	kuranta->dat.cif = 116;
	krei_literon (kuranta->sekv);
	(kuranta->sekv)->ant = kuranta;
	kuranta = kuranta->sekv;
	kuranta->dat.cif = 97;
	krei_literon (kuranta->sekv);
	(kuranta->sekv)->ant = kuranta;
	kuranta = kuranta->sekv;
	kuranta->dat.cif = 114;
	krei_literon (kuranta->sekv);
	(kuranta->sekv)->ant = kuranta;
	kuranta = kuranta->sekv;
	kuranta->dat.cif = 116;
	kuranta->sekv = NULL;
	(LF->sekv)->sekv = NULL;
	krei_literon (kkh);
	krei_literon (kks);
	krei_literon (kps);
	krei_literon (kph);
	krei_literon (kkh->ant);
	krei_literon (kph->sekv);
	ligi_literojn (kkh, kks);
	ligi_literojn (kks, kps);
	ligi_literojn (kps, kph);
	kkh->tip = MD_FUNK_PARENT;
	kkh->dat.funk = LF;
	kks->tip = MD_FUNK_PARENT;
	kks->dat.funk = LF->sekv;
	kps->tip = D_FUNK_PARENT;
	kps->dat.ref = kks;
	kph->tip = D_FUNK_PARENT;
	kph->dat.ref = kkh;
	krei_literon (LKP);
	krei_literon (LKP->sekv);
	krei_literon ((LKP->sekv)->sekv);
	LKP->dat.ref = kps;
	(LKP->sekv)->dat.ref = kph;
	KFS = NULL;
	interp_krei_masxinon (argv[1]);
	ref_lancxi ();
	return EXIT_SUCCESS;
}
