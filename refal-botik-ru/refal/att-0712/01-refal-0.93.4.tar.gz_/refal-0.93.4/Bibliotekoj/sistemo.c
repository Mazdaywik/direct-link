/*
*	sistemo.c - библиотека системных функций.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "../refal.h"
# include <string.h>
# include <sys/types.h>
# include <unistd.h>

void sis_sxargi (void) __attribute__ ((constructor));

void sis_system (void);
void sis_exit (void);
void sis_getpid (void);
void sis_getppid (void);
void sis_chdir (void);
void sis_getcwd (void);


/* ========================================================================== */


extern void ref_eraro (int);
extern void interp_aldoni_enkonstruitan (char *nomo, void (*funk) (void));
extern char *baz_skribi_utf8 (void);
extern unsigned int baz_preni_utf8 (char *, unsigned int *);


/* ========================================================================== */

void
sis_sxargi ()
{

	interp_aldoni_enkonstruitan ("system", sis_system);
	interp_aldoni_enkonstruitan ("exit", sis_exit);
	interp_aldoni_enkonstruitan ("getpid", sis_getpid);
	interp_aldoni_enkonstruitan ("getppid", sis_getppid);
	interp_aldoni_enkonstruitan ("chdir", sis_chdir);
	interp_aldoni_enkonstruitan ("getcwd", sis_getcwd);
	return;
}

/* ========================================================================== */


/*
*	Функция "sis_sistem" исполняет команду оболочки, записанную между
*	KKK и KKP.
*
*	Результатом работы функции является натуральное число s.1, равное
*	(2 * n), если возвращаемое командой оболочки значение n неотрицательно,
*	и равное (2 * (- n) - 1), если возвращаемое командой оболочки значение
*	n отрицательно.
*
*/

void
sis_system ()
{
	signed int n = 0;
	char *linio;
	LITERO *kuranta;

	linio = baz_skribi_utf8 ();
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	n = system (linio);
	free (linio);
	krei_literon (kuranta);
	krei_literon (kuranta->ant);
	krei_literon (kuranta->sekv);
	ligi_literojn (KKK, kuranta->ant);
	ligi_literojn (kuranta->sekv, KKP);
	(kuranta->ant)->sekv = kuranta;
	(kuranta->sekv)->ant = kuranta;
	kuranta->tip = CIFER;
	(kuranta->ant)->tip = MD_LIT_PARENT;
	(kuranta->sekv)->tip = D_LIT_PARENT;
	ligi_parentezojn (kuranta->ant, kuranta->sekv);
	kuranta->dat.cif = (n < 0) ? (unsigned int) (2 * (- n) - 1) :
		(unsigned int) (2 * n);
	return;
}


/*
*	Функция "sis_exit" осуществляет выход из программы. Аргументом функции
*	является натуральное число s.1. Если оно чётно, то родительскому процессу
*	возвращается значение s.1/2. Если оно нечётно, то родительскому процессу
*	возвращается значение (-[s.1/2]-1), где через [n] обозначена целая часть
*	числа n.
*
*/

void
sis_exit ()
{
	signed int n;
	unsigned int l;
	LITERO *kuranta;

	if (!ESTAS_MD_LIT_PARENT (KKK->sekv))
	{
		ref_eraro (1);
	};
	if ((KKK->sekv)->dat.ref != ((KKK->sekv)->sekv)->sekv)
	{
		ref_eraro (1);
	};
	kuranta = (KKK->sekv)->sekv;
	l = kuranta->dat.cif;
	n = (l == (l / 2) * 2) ? ((signed int) l) / 2
		: (- (((signed int) l) / 2)) - 1;
	ligi_literojn (KKK, (kuranta->sekv)->sekv);
	detrui_literon (kuranta->sekv);
	detrui_literon (kuranta->ant);
	detrui_literon (kuranta);
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	exit (n);
	return;
}


/*
*	Функция "sis_getpid" определяет номер текущего процесса.
*
*/

void
sis_getpid ()
{
	LITERO *kuranta;

	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	krei_literon (KKK->sekv);
	(KKK->sekv)->tip = MD_LIT_PARENT;
	(KKK->sekv)->ant = KKK;
	krei_literon (KKP->ant);
	(KKP->ant)->tip = D_LIT_PARENT;
	(KKP->ant)->sekv = KKP;
	ligi_parentezojn (KKK->sekv, KKP->ant);
	krei_literon (kuranta);
	kuranta->tip = CIFER;
	ligi_literojn (KKK->sekv, kuranta);
	ligi_literojn (kuranta, KKP->ant);
	kuranta->dat.cif = (unsigned int) getpid ();
	return;
}


/*
*	Функция "sis_getppid" определяет номер родительского процесса.
*
*/

void
sis_getppid ()
{
	LITERO *kuranta;

	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	krei_literon (KKK->sekv);
	(KKK->sekv)->tip = MD_LIT_PARENT;
	(KKK->sekv)->ant = KKK;
	krei_literon (KKP->ant);
	(KKP->ant)->tip = D_LIT_PARENT;
	(KKP->ant)->sekv = KKP;
	ligi_parentezojn (KKK->sekv, KKP->ant);
	krei_literon (kuranta);
	kuranta->tip = CIFER;
	ligi_literojn (KKK->sekv, kuranta);
	ligi_literojn (kuranta, KKP->ant);
	kuranta->dat.cif = (unsigned int) getppid ();
	return;
}


/*
*	Функция "sis_chdir" изменяет рабочую директорию на ту, имя которой
*	заключено между KKK и KKP.
*
*/

void
sis_chdir ()
{
	char *linio;

	linio = baz_skribi_utf8 ();
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	chdir (linio);
	free (linio);
	return;
}


/*
*	Функция "sis_getcwd" определяет имя рабочей директории.
*
*/

void
sis_getcwd ()
{
	char *linio;
	unsigned int l, pozicio;
	LITERO *kuranta, *sekva;

	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	linio = get_current_dir_name ();
	pozicio = 0;
	while (linio[pozicio] != 0)
	{
		l = baz_preni_utf8 (linio, &pozicio);
		krei_literon (kuranta);
		ligi_literojn (KKP->ant, kuranta);
		kuranta->tip = MD_LIT_PARENT;
		krei_literon (sekva);
		ligi_literojn (kuranta, sekva);
		sekva->tip = CIFER;
		sekva->dat.cif = l;
		krei_literon (kuranta);
		ligi_literojn (sekva, kuranta);
		kuranta->tip = D_LIT_PARENT;
		ligi_parentezojn (sekva->ant, kuranta);
		ligi_literojn (kuranta, KKP);
	};
	free (linio);
	return;
};
