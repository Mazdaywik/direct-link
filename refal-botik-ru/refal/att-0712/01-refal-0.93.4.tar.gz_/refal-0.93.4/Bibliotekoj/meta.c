/*
*	meta.c - библиотека метафункций рефал-машины.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "../refal.h"


void meta_sxargi (void) __attribute__ ((constructor));


void meta_interp (void);
void meta_mu (void);


/* ========================================================================== */


extern void ref_eraro (char);
extern void interp_krei_masxinon (char *);
extern char interp_kompari_nomojn (LITERO *, LITERO *);
extern void interp_aldoni_enkonstruitan (char *nomo, void (*f) (void));
extern char *baz_skribi_utf8 (void);


/* ========================================================================== */

void
meta_sxargi ()
{

	interp_aldoni_enkonstruitan ("interp", meta_interp);
	interp_aldoni_enkonstruitan ("mu", meta_mu);
	return;
}

/* ========================================================================== */


/*
*	Функция "meta_interp" запускает процесс интерпретации файла, имя которого
*	заключено между KKK и KKP.
*
*/

void
meta_interp ()
{
	char *titolo;

	titolo = baz_skribi_utf8 ();
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	interp_krei_masxinon (titolo);
	free (titolo);
	return;
}


/*
*	Функция "meta_mu" определяет функцию с форматом
*			"<mu (имя_функции) аргумент_функции>",
*	которая осуществляет конкретизацию "<имя_функции аргумент_функции>".
*
*/

void
meta_mu ()
{
	char i;
	LITERO *kuranta, *nomo;
	FUNKCIO *f;

	kuranta = KKK->sekv;
	if (!ESTAS_MD_STR_PARENT (kuranta))
	{
		ref_eraro (1);
	};
	if (kuranta->dat.ref == kuranta->sekv)
	{
		ref_eraro (1);
	};
	ligi_literojn (KKK, kuranta->sekv);
	ligi_literojn (KKP->ant, kuranta);
	ligi_literojn (kuranta, KKP);
	kuranta->tip = D_FUNK_PARENT;
	krei_literon (kuranta);
	kuranta->sekv = LKP->sekv;
	kuranta->dat.ref = KKP->ant;
	LKP->sekv = kuranta;
	kuranta = KKK->sekv;
	while (!ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		ligi_literojn (kuranta->sekv, (kuranta->dat.ref)->sekv);
		ligi_literojn (kuranta->ant, kuranta->sekv);
		detrui_literon (kuranta->dat.ref);
		detrui_literon (kuranta);
		kuranta = ((kuranta->ant)->sekv)->sekv;
	};
	(kuranta->ant)->sekv = NULL;
	nomo = KKK->sekv;
	f = LF->sekv;
	do
	{
		f = f->sekv;
		i = interp_kompari_nomojn (nomo, f->nom);
	}
	while (!i && (f->sekv != NULL));
	if (i)
	{
		while (nomo->sekv != NULL)
		{
			nomo = nomo->sekv;
			detrui_literon (nomo->ant);
		};
		detrui_literon (nomo);
	}
	else
	{
		ref_eraro (1);
	};
	ligi_literojn (KKK, kuranta);
	kuranta->tip = MD_FUNK_PARENT;
	kuranta->dat.funk = f;
	return;
}
