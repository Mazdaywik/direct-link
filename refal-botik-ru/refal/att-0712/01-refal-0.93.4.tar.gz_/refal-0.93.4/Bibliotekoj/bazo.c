/*
*	bazo.c - общие функции библиотек.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "../refal.h"


char *baz_skribi_utf8 (void);
char *baz_skribi_ascii (void);
char *baz_skribi_ascii8 (void);
char *baz_skribi_utf16le (unsigned int *);
char *baz_skribi_utf16be (unsigned int *);
char *baz_skribi_utf32le (unsigned int *);
char *baz_skribi_utf32be (unsigned int *);
unsigned int baz_preni_utf8 (char *, unsigned int *);
char baz_legi_utf8 (FILE *, LITERO *);
char baz_legi_ascii (FILE *, LITERO *);
char baz_legi_ascii8 (FILE *, LITERO *);
char baz_legi_utf16le (FILE *, LITERO *);
char baz_legi_utf16be (FILE *, LITERO *);
char baz_legi_utf32le (FILE *, LITERO *);
char baz_legi_utf32be (FILE *, LITERO *);


/* ========================================================================== */


extern void ref_eraro (int);


/* ========================================================================== */


/*
*	Функция "baz_skribi_utf8" возвращает строку в кодировке UTF-8,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом сам текст
*	удаляется.
*
*/

char
*baz_skribi_utf8 ()
{
	char i = 1, *linio;
	unsigned int k = 1, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k++;
		if (c >> 7)
		{
			k++;
			if (c >> 11)
			{
				k++;
				if (c >> 16)
				{
					k++;
					if (c >> 21)
					{
						k++;
						if (c >> 26)
						{
							k++;
							if (c >> 31)
							{
								ref_eraro (1);
							};
						};
					};
				};
			};
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		i = 0;
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		if (!(c >> 7))
		{
			linio[k] = (char) c;
			k++;
			i = 1;
		};
		if ((i == 0) && !(c >> 11))
		{
			linio[k] = (char) ((c >> 6) | 192);
			c <<= 26;
			k++;
			i = 2;
		};
		if ((i == 0) && !(c >> 16))
		{
			linio[k] = (char) ((c >> 12) | 224);
			c <<= 20;
			k++;
			i = 3;
		};
		if ((i == 0) && !(c >> 21))
		{
			linio[k] = (char) ((c >> 18) | 240);
			c <<= 14;
			k++;
			i = 4;
		};
		if ((i == 0) && !(c >> 26))
		{
			linio[k] = (char) ((c >> 24) | 248);
			c <<= 8;
			k++;
			i = 5;
		};
		if (i == 0)
		{
			linio[k] = (char) ((c >> 30) | 252);
			c <<= 2;
			k++;
			i = 6;
		};
		while (i != 1)
		{
			linio[k] = (char) ((c >> 26) | 128);
			c <<= 6;
			k++;
			i--;
		};
	};
	linio[k] = 0;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_skribi_ascii" возвращает строку в кодировке ASCII,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом само выражение
*	удаляется.
*
*/

char
*baz_skribi_ascii ()
{
	char *linio;
	unsigned int k = 1, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k++;
		if (c >> 7)
		{
			ref_eraro (1);
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		linio[k] = (char) c;
		k++;
	};
	linio[k] = 0;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_skribi_ascii8" возвращает строку в кодировке ASCII8,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом
*	само выражение удаляется.
*
*/

char
*baz_skribi_ascii8 ()
{
	char *linio;
	unsigned int k = 1, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k++;
		if (c >> 8)
		{
			ref_eraro (1);
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		linio[k] = (char) c;
		k++;
	};
	linio[k] = 0;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_skribi_utf16le" возвращает строку в кодировке UTF-16LE,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом само выражение
*	удаляется. В качестве значения величины "(*n)" устанавливается
*	длина возвращаемой строки в байтах.
*
*/

char
*baz_skribi_utf16le (unsigned int *n)
{
	char *linio;
	unsigned int k = 0, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k += 2;
		if (c >> 16)
		{
			ref_eraro (1);
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		linio[k] = (char) c;
		k++;
		linio[k] = (char) (c >> 8);
		k++;
	};
	(*n) = k;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_skribi_utf16be" возвращает строку в кодировке UTF-16BE,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом само выражение
*	удаляется. В качестве значения величины "(*n)" устанавливается
*	длина возвращаемой строки в байтах.
*
*/

char
*baz_skribi_utf16be (unsigned int *n)
{
	char *linio;
	unsigned int k = 0, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k += 2;
		if (c >> 16)
		{
			ref_eraro (1);
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		linio[k] = (char) (c >> 8);
		k++;
		linio[k] = (char) c;
		k++;
	};
	(*n) = k;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_skribi_utf32le" возвращает строку в кодировке UTF-32LE,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом само выражение
*	удаляется. В качестве значения величины "(*n)" устанавливается
*	длина возвращаемой строки в байтах.
*
*/

char
*baz_skribi_utf32le (unsigned int *n)
{
	char *linio;
	unsigned int k = 0, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k += 4;
		if (c >> 31)
		{
			ref_eraro (1);
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		linio[k] = (char) c;
		k++;
		linio[k] = (char) (c >> 8);
		k++;
		linio[k] = (char) (c >> 16);
		k++;
		linio[k] = (char) (c >> 24);
		k++;
	};
	(*n) = k;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_skribi_utf32be" возвращает строку в кодировке UTF-32BE,
*	отвечающую тексту, заключённому между KKK и либо KKP, либо
*	ближайшей справа к KKK правой структурной скобкой. При этом само выражение
*	удаляется. В качестве значения величины "(*n)" устанавливается
*	длина возвращаемой строки в байтах.
*
*/

char
*baz_skribi_utf32be (unsigned int *n)
{
	char *linio;
	unsigned int k = 0, c;
	LITERO *kuranta;
	
	kuranta = KKK->sekv;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (kuranta->dat.ref != (kuranta->sekv)->sekv)
		{
			ref_eraro (1);
		};
		c = (kuranta->sekv)->dat.cif;
		kuranta = (kuranta->dat.ref)->sekv;
		k += 4;
		if (c >> 31)
		{
			ref_eraro (1);
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = KKK->sekv;
	k = 0;
	while ((kuranta != KKP) && !ESTAS_D_STR_PARENT (kuranta))
	{
		c = (kuranta->sekv)->dat.cif;
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = (kuranta->dat.ref)->sekv;
		detrui_literon (kuranta->ant);
		linio[k] = (char) (c >> 24);
		k++;
		linio[k] = (char) (c >> 16);
		k++;
		linio[k] = (char) (c >> 8);
		k++;
		linio[k] = (char) c;
		k++;
	};
	(*n) = k;
	ligi_literojn (KKK, kuranta);
	return linio;
}


/*
*	Функция "baz_preni_utf8" считывает из строки "linio" букву
*	(в кодировке UTF-8), начало которой находится в позиции "*pozicio".
*
*	Возвращаемым значением функции является число типа (unsigned int),
*	представляющее собой номер считанной буквы в таблице юникода.
*
*	По окончании работы функции значением параметра "*pozicio" является
*	номер позиции, непосредственно следующей за считанной буквой.
*
*/

unsigned int
baz_preni_utf8 (char *linio, unsigned int *pozicio)
{
	char c, k = 32;
	unsigned int l;

	c = linio[*pozicio];
	(*pozicio)++;
	if (!(c >> 7))
	{
		return (unsigned int) c;
	};
	if ((c >> 6 == 2) || (c >> 1 == 127))
	{
		ref_eraro (1);
	};
	while (c & k)
	{
		k >>= 1;
	};
	k--;
	l = (unsigned int) (c & k);
	k = (~k) << 2;
	while (k)
	{
		c = linio[*pozicio];
		(*pozicio)++;
		if (c >> 6 != 2)
		{
			ref_eraro (1);
		};
		l <<= 6;
		l |= (unsigned int) (c & 63);
		k <<= 1;
	};
	return l;
}


/*
*	Функция "baz_legi_utf8" считывает из файла "dosiero" букву
*	в кодировке UTF-8, и записывает её номер в таблице юникода по адресу
*	"lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_utf8 (FILE *dosiero, LITERO *lit)
{
	char c, k = 32;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	if (!(c >> 7))
	{
		lit->dat.cif = (unsigned int) c;
		return 1;
	};
	if ((c >> 6 == 2) || (c >> 1 == 127))
	{
		lit->dat.cif = 0;
		return 0;
	};
	while (c & k)
	{
		k >>= 1;
	};
	k--;
	lit->dat.cif = (unsigned int) (c & k);
	k = (~k) << 2;
	while (k)
	{
		if (fscanf (dosiero, "%c", &c) == EOF)
		{
			lit->dat.cif = 0;
			return 0;
		};
		if (c >> 6 != 2)
		{
			lit->dat.cif = 0;
			return 0;
		};
		lit->dat.cif <<= 6;
		lit->dat.cif |= (unsigned int) (c & 63);
		k <<= 1;
	};
	return 1;
}


/*
*	Функция "baz_legi_ascii" считывает из файла "dosiero" букву
*	в кодировке ASCII, и записывает её номер по адресу "lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_ascii (FILE *dosiero, LITERO *lit)
{
	char c;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	if (c >> 7)
	{
		lit->dat.cif = 0;
		return 0;
	}
	else
	{
		lit->dat.cif = (unsigned int) c;
	};
	return 1;
}


/*
*	Функция "baz_legi_ascii8" считывает из файла "dosiero" букву
*	в кодировке ASCII8, и записывает её номер по адресу "lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_ascii8 (FILE *dosiero, LITERO *lit)
{
	char c;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif = (unsigned int) c;
	return 1;
}


/*
*	Функция "baz_legi_utf16le" считывает из файла "dosiero" букву
*	в кодировке UTF-16LE, и записывает её номер по адресу "lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_utf16le (FILE *dosiero, LITERO *lit)
{
	char c;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif = (unsigned int) c;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif |= ((unsigned int) c) << 8;
	return 1;
}


/*
*	Функция "baz_legi_utf16be" считывает из файла "dosiero" букву
*	в кодировке UTF-16BE, и записывает её номер по адресу "lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_utf16be (FILE *dosiero, LITERO *lit)
{
	char c;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif = (unsigned int) c;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif <<= 8;
	lit->dat.cif |= (unsigned int) c;
	return 1;
}


/*
*	Функция "baz_legi_utf32le" считывает из файла "dosiero" букву
*	в кодировке UTF-32LE, и записывает её номер по адресу "lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_utf32le (FILE *dosiero, LITERO *lit)
{
	char c;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif = (unsigned int) c;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif |= ((unsigned int) c) << 8;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif |= ((unsigned int) c) << 16;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif |= ((unsigned int) c) << 24;
	return 1;
}


/*
*	Функция "baz_legi_utf32be" считывает из файла "dosiero" букву
*	в кодировке UTF-32BE, и записывает её номер по адресу "lit->dat.cif".
*
*	Возвращаемым значением функции является 1, если считывание прошло успешно,
*	и 0 - иначе.
*
*/

char
baz_legi_utf32be (FILE *dosiero, LITERO *lit)
{
	char c;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif = (unsigned int) c;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif <<= 8;
	lit->dat.cif |= (unsigned int) c;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif <<= 8;
	lit->dat.cif |= (unsigned int) c;
	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	lit->dat.cif <<= 8;
	lit->dat.cif |= (unsigned int) c;
	return 1;
}
