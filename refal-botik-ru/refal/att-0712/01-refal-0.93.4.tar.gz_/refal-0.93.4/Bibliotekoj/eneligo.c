/*
*	eneligo.c - библиотека средств ввода/вывода.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "../refal.h"
# include <string.h>
# include <unistd.h>
# include <errno.h>


/*
*	Структура DOSIERO предназначена для организации списка открытых файлов.
*
*/

typedef struct dosiero
{
	FILE *dat;			/* Указатель на открытый файл */
	unsigned int id;		/* Дескриптор файла */
	struct dosiero *ant;	/* Указатель на предыдущий элемент списка */
	struct dosiero *sekv;	/* Указатель на следующий элемент списка */
} DOSIERO;


DOSIERO *LDos;				/* Начало списка открытых файлов */
DOSIERO *LDosN;			/* Начало списка свободных элементов */


# define krei_dosieron(x) {\
	x = LDosN;\
	if (LDosN->sekv == NULL)\
	{\
		LDosN = (DOSIERO*) malloc (sizeof (DOSIERO));\
		if (LDosN == NULL)\
		{\
			exit (EXIT_FAILURE);\
		};\
		LDosN->sekv = NULL;\
	}\
	else\
	{\
		LDosN = LDosN->sekv;\
	};\
}


# define ligi_dosierojn(x,y) {x->sekv = y; y->ant = x;}
# define detrui_dosieron(x) {ligi_dosierojn (x, LDosN); LDosN = x;}


void enel_sxargi (void) __attribute__ ((constructor));

void enel_open (void);
void enel_close (void);
void enel_put (void);
void enel_get (void);
void enel_arg (void);


DOSIERO *enel_preni_dosieron (unsigned int);


/* ========================================================================== */


extern void ref_eraro (char);
extern void interp_aldoni_enkonstruitan (char *nomo, void (*funk) (void));
extern char *baz_skribi_utf8 (void);
extern char *baz_skribi_ascii (void);
extern char *baz_skribi_ascii8 (void);
extern char *baz_skribi_utf16le (unsigned int *);
extern char *baz_skribi_utf16be (unsigned int *);
extern char *baz_skribi_utf32le (unsigned int *);
extern char *baz_skribi_utf32be (unsigned int *);
extern unsigned int baz_preni_utf8 (char *, int *);
extern char baz_legi_utf8 (FILE *, LITERO *);
extern char baz_legi_ascii (FILE *, LITERO *);
extern char baz_legi_ascii8 (FILE *, LITERO *);
extern char baz_legi_utf16le (FILE *, LITERO *);
extern char baz_legi_utf16be (FILE *, LITERO *);
extern char baz_legi_utf32le (FILE *, LITERO *);
extern char baz_legi_utf32be (FILE *, LITERO *);


/* ========================================================================== */

void
enel_sxargi ()
{

	LDosN = (DOSIERO *) malloc (sizeof (DOSIERO));
	if (LDosN == NULL)
	{
		exit (EXIT_FAILURE);
	};
	LDosN->sekv = NULL;
	krei_dosieron (LDos);
	LDos->id = -1;
	krei_dosieron (LDos->sekv);
	(LDos->sekv)->id = 0;
	(LDos->sekv)->dat = stdin;
	(LDos->sekv)->ant = LDos;
	krei_dosieron ((LDos->sekv)->sekv);
	((LDos->sekv)->sekv)->id = 1;
	((LDos->sekv)->sekv)->dat = stdout;
	((LDos->sekv)->sekv)->ant = LDos->sekv;
	krei_dosieron (((LDos->sekv)->sekv)->sekv);
	(((LDos->sekv)->sekv)->sekv)->id = 2;
	(((LDos->sekv)->sekv)->sekv)->dat = stderr;
	(((LDos->sekv)->sekv)->sekv)->ant = (LDos->sekv)->sekv;
	(((LDos->sekv)->sekv)->sekv)->sekv = NULL;
	interp_aldoni_enkonstruitan ("open", enel_open);
	interp_aldoni_enkonstruitan ("close", enel_close);
	interp_aldoni_enkonstruitan ("put", enel_put);
	interp_aldoni_enkonstruitan ("get", enel_get);
	interp_aldoni_enkonstruitan ("arg", enel_arg);
	return;
}

/* ========================================================================== */


/*
*	Функция "enel_open" открывает файл, имя которого заключено между
*	"(KKK->sekv)->dat.ref" и KKP. Открытому файлу присваивается дескриптор,
*	указанный после "KKK->sekv". В данной реализации дескриптором может
*	выступать натуральное число, заключённое между 0 и 4294967295. Между
*	дескриптором и "(KKK->sekv)->dat.ref" записывается тип открытия -
*	одна из строк 'r', 'r+', 'w', 'w+', 'a', 'a+'.
*
*/

void
enel_open ()
{
	char i, *nomo, c[3];
	unsigned int n;
	LITERO *kuranta;
	DOSIERO *dos;

	if (!ESTAS_MD_STR_PARENT (KKK->sekv))
	{
		ref_eraro (1);
	};
	kuranta = (KKK->sekv)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta))
	{
		ref_eraro (1);
	};
	if (kuranta->dat.ref != (kuranta->sekv)->sekv)
	{
		ref_eraro (1);
	};
	kuranta = kuranta->sekv;
	n = kuranta->dat.cif;
	ligi_literojn (KKK->sekv, (kuranta->sekv)->sekv);
	detrui_literon (kuranta->sekv);
	detrui_literon (kuranta->ant);
	detrui_literon (kuranta);
	kuranta = (KKK->sekv)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta))
	{
		ref_eraro (1);
	};
	kuranta = kuranta->sekv;
	if ((kuranta->dat.cif != 97) && (kuranta->dat.cif != 114)
		&& (kuranta->dat.cif != 119))
	{
		ref_eraro (1);
	};
	c[0] = (char) (kuranta->dat.cif);
	kuranta = kuranta->sekv;
	if (!ESTAS_D_LIT_PARENT (kuranta))
	{
		ref_eraro (1);
	};
	ligi_literojn (KKK->sekv, kuranta->sekv);
	detrui_literon (kuranta->dat.ref);
	detrui_literon (kuranta->ant);
	detrui_literon (kuranta);
	kuranta = (KKK->sekv)->sekv;
	if (ESTAS_D_STR_PARENT (kuranta))
	{
		c[1] = '\0';
		ligi_literojn (KKK, kuranta->sekv);
		detrui_literon (kuranta->dat.ref);
		detrui_literon (kuranta);
	}
	else
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		kuranta = kuranta->sekv;
		if (kuranta->dat.cif != 43)
		{
			ref_eraro (1);
		};
		c[1] = '+';
		c[2] = '\0';
		kuranta = kuranta->sekv;
		if (!ESTAS_D_LIT_PARENT (kuranta))
		{
			ref_eraro (1);
		};
		if (!ESTAS_D_STR_PARENT (kuranta->sekv))
		{
			ref_eraro (1);
		};
		ligi_literojn (KKK, (kuranta->sekv)->sekv);
		detrui_literon (kuranta->dat.ref);
		detrui_literon (kuranta->ant);
		detrui_literon ((kuranta->sekv)->dat.ref);
		detrui_literon (kuranta->sekv);
		detrui_literon (kuranta);
	};
	dos = LDos;
	i = 1;
	do
	{
		if (dos->sekv == NULL)
		{
			i = 0;
		}
		else
		{
			if ((dos->sekv)->id == n)
			{
				i = 0;
			};
			dos = dos->sekv;
		};
	}
	while (i);
	if (dos->id == n)
	{
		if (dos->dat != NULL)
		{
			fclose (dos->dat);
		};
	}
	else
	{
		krei_dosieron (dos->sekv);
		(dos->sekv)->ant = dos;
		dos = dos->sekv;
		dos->id = n;
		dos->sekv = NULL;
	};
	nomo = baz_skribi_utf8 ();
	dos->dat = fopen (nomo, c);
	free (nomo);
	return;
}


/*
*	Функция "enel_close" закрывает файл, дескриптор которого указан между
*	KKK и KKP.
*
*/

void
enel_close ()
{
	unsigned int n;
	LITERO *kuranta;
	DOSIERO *dos;

	if (!ESTAS_MD_LIT_PARENT (KKK->sekv))
	{
		ref_eraro (1);
	};
	if ((KKK->sekv)->dat.ref != ((KKK->sekv)->sekv)->sekv)
	{
		ref_eraro (1);
	};
	kuranta = (KKK->sekv)->sekv;
	n = kuranta->dat.cif;
	ligi_literojn (KKK, (kuranta->sekv)->sekv);
	detrui_literon (kuranta->sekv);
	detrui_literon (kuranta->ant);
	detrui_literon (kuranta);
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	dos = enel_preni_dosieron (n);
	if (dos != NULL)
	{
		if (dos->dat != NULL)
		{
			fclose (dos->dat);
		};
		if (dos->sekv == NULL)
		{
			(dos->ant)->sekv = NULL;
			detrui_dosieron (dos);
		}
		else
		{
			ligi_dosierojn (dos->ant, dos->sekv);
			detrui_dosieron (dos);
		};
	};
	return;
}


/*
*	Макрос "DIFINI_SIGNARON" определяет, название какой кодировки
*	записано в строке "linio", и соответствующим образом устанавливает
*	значение параметра "i".
*
*/

#define DIFINI_SIGNARON {\
		if ((strcmp (linio, "utf8") == 0) || (strcmp (linio, "") == 0))\
		{\
			i = 1;\
		};\
		if (!i)\
		{\
			if (strcmp (linio, "ascii") == 0)\
			{\
				i = 2;\
			};\
		};\
		if (!i)\
		{\
			if (strcmp (linio, "ascii8") == 0)\
			{\
				i = 3;\
			};\
		};\
		if (!i)\
		{\
			if (strcmp (linio, "utf16le") == 0)\
			{\
				i = 4;\
			};\
		};\
		if (!i)\
		{\
			if (strcmp (linio, "utf16be") == 0)\
			{\
				i = 5;\
			};\
		};\
		if (!i)\
		{\
			if (strcmp (linio, "utf32le") == 0)\
			{\
				i = 6;\
			};\
		};\
		if (!i)\
		{\
			if (strcmp (linio, "utf32be") == 0)\
			{\
				i = 7;\
			};\
		};\
		free (linio);\
	}


/*
*	Функция "enel_put" выводит строку, заключённую между
*	"(KKK->sekv)->dat.ref" и KKP, в файл, дескриптор которого указан между
*	"KKK->sekv" и "(KKK->sekv)->dat.ref".
*
*	Возможно использование после дескриптора файла дополнительного параметра
*	(типа кодировки). По умолчанию используется кодировка UTF-8.
*
*/

void
enel_put ()
{
	char i = 0, *linio;
	unsigned int n, k;
	LITERO *kuranta;
	DOSIERO *dos;

	if (!ESTAS_MD_STR_PARENT (KKK->sekv))
	{
		ref_eraro (1);
	};
	kuranta = (KKK->sekv)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta))
	{
		ref_eraro (1);
	};
	if (kuranta->dat.ref != (kuranta->sekv)->sekv)
	{
		ref_eraro (1);
	};
	kuranta = kuranta->sekv;
	n = kuranta->dat.cif;
	ligi_literojn (KKK, (kuranta->sekv)->sekv);
	detrui_literon (kuranta->sekv);
	detrui_literon ((kuranta->ant)->ant);
	detrui_literon (kuranta->ant);
	detrui_literon (kuranta);
	linio = baz_skribi_utf8 ();
	kuranta = (KKK->sekv)->sekv;
	detrui_literon (KKK->sekv);
	ligi_literojn (KKK, kuranta);
	DIFINI_SIGNARON;
	switch (i)
	{
	case 1:
		linio = baz_skribi_utf8 ();
		break;
		
	case 2:
		linio = baz_skribi_ascii ();
		break;
	
	case 3:
		linio = baz_skribi_ascii8 ();
		break;

	case 4:
		linio = baz_skribi_utf16le (&k);
		break;

	case 5:
		linio = baz_skribi_utf16be (&k);
		break;

	case 6:
		linio = baz_skribi_utf32le (&k);
		break;

	case 7:
		linio = baz_skribi_utf32be (&k);
		break;
		
	default:
		ref_eraro (1);
		break;
	};
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	dos = enel_preni_dosieron (n);
	if (dos != NULL)
	{
		if (dos->dat != NULL)
		{
			if (i < 4)
			{
				fputs (linio, dos->dat);
			}
			else
			{
				fwrite (linio, 1, k, dos->dat);
			};
		};
	};
	free (linio);
	return;
}


/*
*	Функция "enel_get" считывает символ из файла, дескриптор которого указан
*	между "KKK->sekv" и "(KKK->sekv)->dat.ref". В случае невозможности
*	считывания возвращается пустое выражение.
*
*	Возможно использование после дескриптора файла дополнительного параметра
*	(типа кодировки). По умолчанию используется кодировка UTF-8.
*
*/

void
enel_get ()
{
	char i = 0, *linio;
	unsigned int n;
	LITERO *kuranta;
	DOSIERO *dos;

	if (!ESTAS_MD_STR_PARENT (KKK->sekv))
	{
		ref_eraro (1);
	};
	kuranta = (KKK->sekv)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta))
	{
		ref_eraro (1);
	};
	if (kuranta->dat.ref != (kuranta->sekv)->sekv)
	{
		ref_eraro (1);
	};
	kuranta = kuranta->sekv;
	n = kuranta->dat.cif;
	ligi_literojn (KKK, (kuranta->sekv)->sekv);
	detrui_literon (kuranta->sekv);
	detrui_literon ((kuranta->ant)->ant);
	detrui_literon (kuranta->ant);
	detrui_literon (kuranta);
	linio = baz_skribi_utf8 ();
	kuranta = (KKK->sekv)->sekv;
	detrui_literon (KKK->sekv);
	ligi_literojn (KKK, kuranta);
	DIFINI_SIGNARON;
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	dos = enel_preni_dosieron (n);
	if (dos != NULL)
	{
		if (dos->dat != NULL)
		{
			krei_literon (kuranta);
			switch (i)
			{
			case 1:
				i = baz_legi_utf8 (dos->dat, kuranta);
				break;
				
			case 2:
				i = baz_legi_ascii (dos->dat, kuranta);
				break;
			
			case 3:
				i = baz_legi_ascii8 (dos->dat, kuranta);
				break;
			
			case 4:
				i = baz_legi_utf16le (dos->dat, kuranta);
				break;
			
			case 5:
				i = baz_legi_utf16be (dos->dat, kuranta);
				break;
			
			case 6:
				i = baz_legi_utf32le (dos->dat, kuranta);
				break;
			
			case 7:
				i = baz_legi_utf32be (dos->dat, kuranta);
				break;
			
			default:
				ref_eraro (1);
				break;
			};
			if (i)
			{
				kuranta->tip = CIFER;
				krei_literon (kuranta->ant);
				krei_literon (kuranta->sekv);
				(kuranta->ant)->sekv = kuranta;
				(kuranta->sekv)->ant = kuranta;
				(kuranta->ant)->tip = MD_LIT_PARENT;
				(kuranta->sekv)->tip = D_LIT_PARENT;
				ligi_parentezojn (kuranta->ant, kuranta->sekv);
				ligi_literojn (KKK, kuranta->ant);
				ligi_literojn (kuranta->sekv, KKP);
			}
			else
			{
				detrui_literon (kuranta);
			};
		};
	};
	return;
};


/*
*	Функция "enel_arg" составляет список аргументов программы.
*
*/

void
enel_arg ()
{
	unsigned int l, k = 1, pozicio;
	LITERO *kuranta, *sekva;
	
	if (KKK->sekv != KKP)
	{
		ref_eraro (1);
	};
	while (k < ARGC)
	{
		krei_literon (kuranta);
		krei_literon (sekva);
		kuranta->tip = MD_STR_PARENT;
		sekva->tip = D_STR_PARENT;
		ligi_literojn (kuranta, sekva);
		ligi_parentezojn (kuranta, sekva);
		ligi_literojn (KKP->ant, kuranta);
		ligi_literojn (sekva, KKP);
		pozicio = 0;
		while (ARGV[k][pozicio] != 0)
		{
			l = baz_preni_utf8 (ARGV[k], &pozicio);
			krei_literon (kuranta);
			ligi_literojn ((KKP->ant)->ant, kuranta);
			kuranta->tip = MD_LIT_PARENT;
			krei_literon (sekva);
			ligi_literojn (kuranta, sekva);
			sekva->tip = CIFER;
			sekva->dat.cif = l;
			krei_literon (kuranta);
			ligi_literojn (sekva, kuranta);
			kuranta->tip = D_LIT_PARENT;
			ligi_parentezojn (sekva->ant, kuranta);
			ligi_literojn (kuranta, KKP->ant);
		};
		k++;
	};
	return;
};


/* ========================================================================== */


DOSIERO
*enel_preni_dosieron (unsigned int n)
{
	char i;
	DOSIERO *dos;

	dos = LDos;
	i = 1;
	do
	{
		if (dos->sekv == NULL)
		{
			i = 0;
		}
		else
		{
			if ((dos->sekv)->id == n)
			{
				i = 0;
			};
			dos = dos->sekv;
		};
	}
	while (i);
	if (dos->id == n)
	{
		return dos;
	}
	else
	{
		return NULL;
	};
}
