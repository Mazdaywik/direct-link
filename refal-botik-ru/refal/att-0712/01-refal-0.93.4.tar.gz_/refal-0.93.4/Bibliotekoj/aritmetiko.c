/*
*	aritmetiko.c - библиотека арифметических функций языка Рефал.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "../refal.h"


void arit_sxargi (void) __attribute__ ((constructor));


void arit_add (void);
void arit_sub (void);
void arit_mul (void);
void arit_divmod (void);
void arit_div (void);
void arit_mod (void);
void arit_symb (void);
void arit_numb (void);
void arit_lengw (void);


void arit_sumigi (LITERO *, unsigned long long);
void arit_subtrahi (LITERO *, unsigned long long);


/* ========================================================================== */


extern void ref_eraro (int);
extern void interp_aldoni_enkonstruitan (char *nomo, void (*funk) (void));


/* ========================================================================== */


void
arit_sxargi ()
{

	interp_aldoni_enkonstruitan ("add", arit_add);
	interp_aldoni_enkonstruitan ("sub", arit_sub);
	interp_aldoni_enkonstruitan ("mul", arit_mul);
	interp_aldoni_enkonstruitan ("divmod", arit_divmod);
	interp_aldoni_enkonstruitan ("div", arit_div);
	interp_aldoni_enkonstruitan ("mod", arit_mod);
	interp_aldoni_enkonstruitan ("symb", arit_symb);
	interp_aldoni_enkonstruitan ("numb", arit_numb);
	interp_aldoni_enkonstruitan ("lengw", arit_lengw);
	return;
}


/* ========================================================================== */


/*
*	Функция "arit_add" производит сложение пары чисел, заключённых между
*	KKK и KKP.
*
*/

void
arit_add ()
{
	unsigned long long k = 0;
	LITERO *kuranta1, *kuranta2;

	kuranta1 = KKK->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta1))
	{
		ref_eraro (1);
	};
	kuranta2 = (kuranta1->dat.ref)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta2))
	{
		ref_eraro (1);
	};
	if ((kuranta2->dat.ref)->sekv != KKP)
	{
		ref_eraro (1);
	};
	kuranta1 = kuranta1->sekv;
	kuranta2 = kuranta2->sekv;
	detrui_literon (kuranta2->ant);
	while (ESTAS_CIFER (kuranta1) && ESTAS_CIFER (kuranta2))
	{
		k += kuranta1->dat.cif;
		k += kuranta2->dat.cif;
		kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
		k /= 4294967296ULL;
		kuranta1 = kuranta1->sekv;
		kuranta2 = kuranta2->sekv;
		detrui_literon (kuranta2->ant);
	};
	if (ESTAS_D_LIT_PARENT (kuranta2))
	{
		while (ESTAS_CIFER (kuranta1))
		{
			k += kuranta1->dat.cif;
			kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
			k /= 4294967296ULL;
			kuranta1 = kuranta1->sekv;
		};
		ligi_parentezojn (kuranta1->dat.ref, kuranta2);
		if (k != 0)
		{
			kuranta1->tip = CIFER;
			kuranta1->dat.cif = (unsigned int) k;
			ligi_literojn (kuranta1, kuranta2);
		}
		else
		{
			detrui_literon (kuranta1);
			ligi_literojn (kuranta1->ant, kuranta2);
		};
	}
	else
	{
		kuranta1->tip = CIFER;
		ligi_literojn (kuranta1, kuranta2);
		kuranta1 = kuranta1->dat.ref;
		while (ESTAS_CIFER (kuranta2))
		{
			k += kuranta2->dat.cif;
			(kuranta2->ant)->dat.cif = (unsigned int) (k % 4294967296ULL);
			k /= 4294967296ULL;
			kuranta2 = kuranta2->sekv;
		};
		ligi_parentezojn (kuranta1, kuranta2);
		if (k != 0)
		{
			(kuranta2->ant)->dat.cif = (unsigned int) k;
		}
		else
		{
			detrui_literon (kuranta2->ant);
			ligi_literojn ((kuranta2->ant)->ant, kuranta2);
		};
	};
	return;
}


/*
*	Функция "arit_sub" производит вычитание пары чисел, заключённых между
*	KKK и KKP.
*
*	ЗАМЕЧАНИЕ: осуществляется операция, обозначаемая в рекурсивной арифметике
*	'минусом с точкой': результатом вычитания большего числа из меньшего
*	по определению считается 0.
*
*/

void
arit_sub ()
{
	unsigned long long k = 1;
	LITERO *kuranta1, *kuranta2;

	kuranta1 = KKK->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta1))
	{
		ref_eraro (1);
	};
	kuranta2 = (kuranta1->dat.ref)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta2))
	{
		ref_eraro (1);
	};
	if ((kuranta2->dat.ref)->sekv != KKP)
	{
		ref_eraro (1);
	};
	kuranta1 = kuranta1->sekv;
	kuranta2 = kuranta2->sekv;
	detrui_literon (kuranta2->ant);
	while (ESTAS_CIFER (kuranta1) && ESTAS_CIFER (kuranta2))
	{
		k += 4294967295ULL + kuranta1->dat.cif;
		k -= kuranta2->dat.cif;
		kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
		k /= 4294967296ULL;
		kuranta1 = kuranta1->sekv;
		kuranta2 = kuranta2->sekv;
		detrui_literon (kuranta2->ant);
	};
	if (ESTAS_D_LIT_PARENT (kuranta2))
	{
		while (ESTAS_CIFER (kuranta1) && (k != 1))
		{
			k += 4294967295ULL + kuranta1->dat.cif;
			kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
			k /= 4294967296ULL;
			kuranta1 = kuranta1->sekv;
		};
		if (k != 1)
		{
			while (!ESTAS_MD_LIT_PARENT (kuranta1->ant))
			{
				detrui_literon (kuranta1);
				kuranta1 = kuranta1->ant;
			};
			ligi_literojn (kuranta1, kuranta2);
			ligi_parentezojn (kuranta1->ant, kuranta2);
			kuranta1->dat.cif = 0;
		}
		else
		{
			while (!ESTAS_D_LIT_PARENT (kuranta1))
			{
				kuranta1 = kuranta1->sekv;
			};
			ligi_literojn (kuranta1->ant, kuranta2);
			ligi_parentezojn (kuranta1->dat.ref, kuranta2);
			detrui_literon (kuranta1);
		};
	}
	else
	{
		while (!ESTAS_D_LIT_PARENT (kuranta2))
		{
			kuranta2 = kuranta2->sekv;
			detrui_literon (kuranta2->ant);
		};
		while (!ESTAS_MD_LIT_PARENT (kuranta1->ant))
		{
			detrui_literon (kuranta1);
			kuranta1 = kuranta1->ant;
		};
		ligi_literojn (kuranta1, kuranta2);
		ligi_parentezojn (kuranta1->ant, kuranta2);
		kuranta1->dat.cif = 0;
	};
	kuranta2 = (KKP->ant)->ant;
	while ((kuranta2->dat.cif == 0) && ESTAS_CIFER (kuranta2->ant))
	{
		ligi_literojn (kuranta2->ant, kuranta2->sekv);
		detrui_literon (kuranta2);
		kuranta2 = kuranta2->ant;
	};
	return;
}


/*
*	Функция "arit_mul" производит перемножение пары чисел, заключённых между
*	KKK и KKP.
*
*/

void
arit_mul ()
{
	unsigned long long k;
	LITERO *kuranta1, *kuranta2, *kuranta0, *kuranta;

	kuranta1 = KKK->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta1))
	{
		ref_eraro (1);
	};
	kuranta2 = (kuranta1->dat.ref)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta2))
	{
		ref_eraro (1);
	};
	if ((kuranta2->dat.ref)->sekv != KKP)
	{
		ref_eraro (1);
	};
	kuranta1 = kuranta1->sekv;
	kuranta2 = kuranta2->sekv;
	krei_literon (KKK->sekv);
	(KKK->sekv)->ant = KKK;
	(KKK->sekv)->tip = MD_LIT_PARENT;
	krei_literon (KKP->ant);
	(KKP->ant)->sekv = KKP;
	(KKP->ant)->tip = D_LIT_PARENT;
	ligi_parentezojn (KKK->sekv, KKP->ant);
	krei_literon (kuranta);
	kuranta->tip = CIFER;
	kuranta->dat.cif = 0;
	ligi_literojn (KKK->sekv, kuranta);
	ligi_literojn (kuranta, KKP->ant);
	kuranta0 = kuranta;
	while (!ESTAS_D_LIT_PARENT (kuranta2))
	{
		while (!ESTAS_D_LIT_PARENT (kuranta1))
		{
			k = kuranta1->dat.cif;
			k *= kuranta2->dat.cif;
			arit_sumigi (kuranta, k);
			kuranta1 = kuranta1->sekv;
			kuranta = kuranta->sekv;
			if (ESTAS_D_LIT_PARENT (kuranta))
			{
				krei_literon ((kuranta->ant)->sekv);
				((kuranta->ant)->sekv)->ant = kuranta->ant;
				ligi_literojn ((kuranta->ant)->sekv, kuranta);
				kuranta = kuranta->ant;
				kuranta->tip = CIFER;
				kuranta->dat.cif = 0;
			};
		};
		kuranta2 = kuranta2->sekv;
		kuranta1 = (kuranta1->dat.ref)->sekv;
		kuranta0 = kuranta0->sekv;
		if (ESTAS_D_LIT_PARENT (kuranta0))
		{
			krei_literon ((kuranta0->ant)->sekv);
			((kuranta0->ant)->sekv)->ant = kuranta0->ant;
			ligi_literojn ((kuranta0->ant)->sekv, kuranta0);
			kuranta0 = kuranta0->ant;
			kuranta0->tip = CIFER;
			kuranta0->dat.cif = 0;
		};
		kuranta = kuranta0;
	};
	do
	{
		detrui_literon (kuranta2);
		kuranta2 = kuranta2->ant;
	}
	while (!ESTAS_MD_LIT_PARENT (kuranta2));
	do
	{
		detrui_literon (kuranta2);
		kuranta2 = kuranta2->ant;
	}
	while (!ESTAS_MD_LIT_PARENT (kuranta2));
	detrui_literon (kuranta2);
	kuranta = (KKP->ant)->ant;
	while ((kuranta->dat.cif == 0) && ESTAS_CIFER (kuranta->ant))
	{
		ligi_literojn (kuranta->ant, kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
	};
	return;
}


/*
*	Функция "arit_divmod" производит целочисленное деление с остатком
*	пары чисел, заключённых между KKK и KKP. Результатом является
*	пара из целочисленного частного и остатка.
*
*/

void
arit_divmod ()
{
	char i = 1;
	unsigned long long k;
	LITERO *kuranta1, *kuranta2, *kuranta3, *lasta1, *kuranta;

	kuranta1 = KKK->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta1))
	{
		ref_eraro (1);
	};
	kuranta2 = (kuranta1->dat.ref)->sekv;
	if (!ESTAS_MD_LIT_PARENT (kuranta2))
	{
		ref_eraro (1);
	};
	if ((kuranta2->dat.ref)->sekv != KKP)
	{
		ref_eraro (1);
	};
	if (((kuranta2->dat.ref)->ant)->dat.cif == 0)
	{
		ref_eraro (1);
	};
	krei_literon (kuranta);
	kuranta->tip = MD_LIT_PARENT;
	ligi_literojn (KKK, kuranta);
	krei_literon (kuranta);
	kuranta->tip = CIFER;
	kuranta->dat.cif = 0;
	ligi_literojn (KKK->sekv, kuranta);
	krei_literon (kuranta->sekv);
	(kuranta->sekv)->tip = D_LIT_PARENT;
	(kuranta->sekv)->ant = kuranta;
	ligi_parentezojn (kuranta->ant, kuranta->sekv);
	ligi_literojn (kuranta->sekv, kuranta1);
	kuranta1 = kuranta1->sekv;
	kuranta2 = kuranta2->sekv;
	lasta1 = kuranta1;
	if (ESTAS_D_LIT_PARENT (kuranta1->sekv))
	{
		if (ESTAS_D_LIT_PARENT (kuranta2->sekv))
		{
			kuranta->dat.cif = (kuranta1->dat.cif)
				/ (kuranta2->dat.cif);
			kuranta1->dat.cif %= (kuranta2->dat.cif);
		};
	}
	else
	{
		kuranta1 = kuranta1->sekv;
		while (ESTAS_CIFER (kuranta1->sekv) && ESTAS_CIFER (kuranta2->sekv))
		{
			kuranta1 = kuranta1->sekv;
			kuranta2 = kuranta2->sekv;
		};
		if (ESTAS_CIFER (kuranta2->sekv))
		{
			i = 0;
		};
		if (ESTAS_CIFER ((kuranta2->sekv)->sekv))
		{
			i = 2;
		};
		while (ESTAS_CIFER (kuranta1->sekv))
		{
			kuranta1 = kuranta1->sekv;
			lasta1 = lasta1->sekv;
		};
		while (ESTAS_CIFER (lasta1->ant))
		{
			while (kuranta1->dat.cif != 0)
			{
				k = 4294967296ULL * kuranta1->dat.cif;
				k += (kuranta1->ant)->dat.cif;
				k /= 1ULL + kuranta2->dat.cif;
				arit_sumigi (kuranta, k);
				kuranta3 = kuranta1->ant;
				do
				{
					arit_subtrahi (kuranta3, (k % 4294967296ULL)
						* kuranta2->dat.cif);
					if (k >= 4294967296ULL)
					{
						arit_subtrahi (kuranta3->sekv, (k / 4294967296ULL)
							* kuranta2->dat.cif);
					};
					kuranta3 = kuranta3->ant;
					kuranta2 = kuranta2->ant;
				}
				while (ESTAS_CIFER (kuranta2));
				kuranta2 = (KKP->ant)->ant;
			};
			kuranta1 = kuranta1->ant;
			lasta1 = lasta1->ant;
			krei_literon (kuranta->ant);
			(kuranta->ant)->sekv = kuranta;
			kuranta = kuranta->ant;
			kuranta->tip = CIFER;
			kuranta->dat.cif = 0;
			ligi_literojn (KKK->sekv, kuranta);
		};
		switch (i)
		{
		case 1:
			k = 4294967296ULL * kuranta1->dat.cif;
			k += (kuranta1->ant)->dat.cif;
			while (k > kuranta2->dat.cif)
			{
				k /= 1ULL + kuranta2->dat.cif;
				arit_sumigi (kuranta, k);
				kuranta3 = kuranta1->ant;
				do
				{
					arit_subtrahi (kuranta3, (k % 4294967296ULL)
						* kuranta2->dat.cif);
					if (k >= 4294967296ULL)
					{
						arit_subtrahi (kuranta3->sekv, (k / 4294967296ULL)
							* kuranta2->dat.cif);
					};
					kuranta3 = kuranta3->ant;
					kuranta2 = kuranta2->ant;
				}
				while (ESTAS_CIFER (kuranta2));
				kuranta2 = (KKP->ant)->ant;
				k = 4294967296ULL * kuranta1->dat.cif;
				k += (kuranta1->ant)->dat.cif;
			};
			kuranta1 = kuranta1->ant;
			if (kuranta1->dat.cif == kuranta2->dat.cif)
			{
				kuranta3 = kuranta1;
				while ((kuranta3->dat.cif == kuranta2->dat.cif)
					&& ESTAS_CIFER (kuranta3->ant))
				{
					kuranta3 = kuranta3->ant;
					kuranta2 = kuranta2->ant;
				};
				if (kuranta3->dat.cif >= kuranta2->dat.cif)
				{
					arit_sumigi (kuranta, 1);
					while (kuranta1 != kuranta3)
					{
						kuranta1->dat.cif = 0;
						kuranta1 = kuranta1->ant;
					};
					while (!ESTAS_MD_LIT_PARENT (kuranta2))
					{
						arit_subtrahi (kuranta1,
							(unsigned long long) kuranta2->dat.cif);
						kuranta1 = kuranta1->ant;
						kuranta2 = kuranta2->ant;
					};
				};
			};
			break;

		case 0:
			kuranta2 = kuranta2->sekv;
			while (kuranta1->dat.cif > kuranta2->dat.cif)
			{
				k = kuranta1->dat.cif / (1ULL + kuranta2->dat.cif);
				arit_sumigi (kuranta, k);
				kuranta3 = kuranta1;
				do
				{
					arit_subtrahi (kuranta3, (k % 4294967296ULL)
						* kuranta2->dat.cif);
					if (k >= 4294967296ULL)
					{
						arit_subtrahi (kuranta3->sekv, (k / 4294967296ULL)
							* kuranta2->dat.cif);
					};
					kuranta3 = kuranta3->ant;
					kuranta2 = kuranta2->ant;
				}
				while (ESTAS_CIFER (kuranta2));
				kuranta2 = (KKP->ant)->ant;
			};
			if (kuranta1->dat.cif == kuranta2->dat.cif)
			{
				kuranta3 = kuranta1;
				while ((kuranta3->dat.cif == kuranta2->dat.cif)
					&& ESTAS_CIFER (kuranta3->ant))
				{
					kuranta3 = kuranta3->ant;
					kuranta2 = kuranta2->ant;
				};
				if (kuranta3->dat.cif >= kuranta2->dat.cif)
				{
					arit_sumigi (kuranta, 1);
					while (kuranta1 != kuranta3)
					{
						kuranta1->dat.cif = 0;
						kuranta1 = kuranta1->ant;
					};
					while (!ESTAS_MD_LIT_PARENT
					       (kuranta2))
					{
						arit_subtrahi (kuranta1,
							(unsigned long long) kuranta2->dat.cif);
						kuranta1 = kuranta1->ant;
						kuranta2 = kuranta2->ant;
					};
				};
			};
			break;

		default:
			break;
		};
	};
	kuranta = (KKP->ant)->ant;
	do
	{
		detrui_literon (kuranta->sekv);
		kuranta = kuranta->ant;
	}
	while (!ESTAS_MD_LIT_PARENT (kuranta));
	ligi_literojn (kuranta->ant, KKP);
	detrui_literon (kuranta->sekv);
	detrui_literon (kuranta);
	kuranta = ((KKK->sekv)->dat.ref)->ant;
	while ((kuranta->dat.cif == 0) && ESTAS_CIFER (kuranta->ant))
	{
		ligi_literojn (kuranta->ant, kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
	};
	kuranta = (KKP->ant)->ant;
	while ((kuranta->dat.cif == 0) && ESTAS_CIFER (kuranta->ant))
	{
		ligi_literojn (kuranta->ant, kuranta->sekv);
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
	};
	return;
}


/*
*	Функция "arit_div" производит целочисленное деление пары чисел,
*	заключённых между KKK и KKP.
*
*/

void
arit_div ()
{
	LITERO *kuranta;

	arit_divmod ();
	kuranta = KKP->ant;
	while (!ESTAS_MD_LIT_PARENT (kuranta))
	{
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
	};
	ligi_literojn (kuranta->ant, KKP);
	detrui_literon (kuranta);
	return;
}


/*
*	Функция "arit_mod" производит взятие остатка от целочисленного деления
*	пары чисел, заключённых между KKK и KKP.
*
*/

void
arit_mod ()
{
	LITERO *kuranta;

	arit_divmod ();
	kuranta = (KKK->sekv)->dat.ref;
	ligi_literojn (KKK, kuranta->sekv);
	while (kuranta != KKK)
	{
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
	};
	return;
}


/*
*	Функция "arit_symb" перерабатывает натуральное число в его десятичную
*	запись.
*
*/

void
arit_symb ()
{
	unsigned long long l;
	LITERO *kuranta, *kuranta1, *unua;

	unua = KKK->sekv;
	if (!ESTAS_MD_LIT_PARENT (unua))
	{
		ref_eraro (1);
	};
	if ((unua->dat.ref)->sekv != KKP)
	{
		ref_eraro (1);
	};
	if ((unua->dat.ref == (unua->sekv)->sekv)
		&& ((unua->sekv)->dat.cif == 0))
	{
		(unua->sekv)->dat.cif = 48;
		return;
	};
	ligi_literojn (KKK, KKP);
	unua = unua->dat.ref;
	while (unua->dat.ref != unua->ant)
	{
		krei_literon (kuranta);
		krei_literon (kuranta->ant);
		krei_literon (kuranta->sekv);
		(kuranta->ant)->sekv = kuranta;
		(kuranta->sekv)->ant = kuranta;
		ligi_literojn (kuranta->sekv, KKK->sekv);
		ligi_literojn (KKK, kuranta->ant);
		(kuranta->ant)->tip = MD_LIT_PARENT;
		(kuranta->sekv)->tip = D_LIT_PARENT;
		ligi_parentezojn (kuranta->ant, kuranta->sekv);
		kuranta->tip = CIFER;
		kuranta1 = unua->ant;
		l = 0;
		while (ESTAS_CIFER (kuranta1))
		{
			l <<= 32;
			l += kuranta1->dat.cif;
			kuranta1->dat.cif = (unsigned int) (l / 10);
			l = l % 10;
			kuranta1 = kuranta1->ant;
		};
		kuranta->dat.cif = (unsigned int) (l + 48);
		if ((unua->ant)->dat.cif == 0)
		{
			detrui_literon (unua->ant);
			ligi_literojn ((unua->ant)->ant, unua);
		};
	};
	detrui_literon (unua->ant);
	detrui_literon (unua);
	return;
}


/*
*	Функция "arit_numb" перерабатывает десятичную запись натурального числа
*	в само это число.
*
*/

void
arit_numb ()
{
	unsigned long long k;
	LITERO *kuranta, *kuranta1;

	kuranta1 = KKK->sekv;
	if (kuranta1 == KKP)
	{
		ref_eraro (1);
	};
	krei_literon (kuranta);
	krei_literon (kuranta->ant);
	krei_literon (kuranta->sekv);
	(kuranta->ant)->sekv = kuranta;
	(kuranta->sekv)->ant = kuranta;
	ligi_literojn (kuranta->sekv, KKK->sekv);
	ligi_literojn (KKK, kuranta->ant);
	(kuranta->ant)->tip = MD_LIT_PARENT;
	(kuranta->sekv)->tip = D_LIT_PARENT;
	ligi_parentezojn (kuranta->ant, kuranta->sekv);
	kuranta->tip = CIFER;
	kuranta->dat.cif = 0;
	while (kuranta1 != KKP)
	{
		if (!ESTAS_MD_LIT_PARENT (kuranta1))
		{
			ref_eraro (1);
		};
		if (kuranta1->dat.ref != (kuranta1->sekv)->sekv)
		{
			ref_eraro (1);
		};
		if (((kuranta1->sekv)->dat.cif < 48)
			|| ((kuranta1->sekv)->dat.cif > 57))
		{
			ref_eraro (1);
		};
		while (!ESTAS_MD_LIT_PARENT (kuranta))
		{
			k = 9ULL * kuranta->dat.cif;
			arit_sumigi (kuranta, k);
			kuranta = kuranta->ant;
		};
		arit_sumigi (kuranta->sekv, (kuranta1->sekv)->dat.cif - 48ULL);
		kuranta = (kuranta->dat.ref)->ant;
		ligi_literojn (kuranta1->ant, (kuranta1->dat.ref)->sekv);
		detrui_literon (kuranta1->dat.ref);
		detrui_literon (kuranta1->sekv);
		detrui_literon (kuranta1);
		kuranta1 = (kuranta1->ant)->sekv;
	};
	return;
}


/*
*	Функция "arit_lengw" добавляет перед выражением числовое значение его
*	длины в термах.
*
*/

void
arit_lengw ()
{
	LITERO *kuranta, *kuranta1;

	kuranta1 = KKK->sekv;
	krei_literon (kuranta);
	krei_literon (kuranta->ant);
	krei_literon (kuranta->sekv);
	(kuranta->ant)->sekv = kuranta;
	(kuranta->sekv)->ant = kuranta;
	ligi_literojn (kuranta->sekv, kuranta1);
	ligi_literojn (KKK, kuranta->ant);
	(kuranta->ant)->tip = MD_LIT_PARENT;
	(kuranta->sekv)->tip = D_LIT_PARENT;
	ligi_parentezojn (kuranta->ant, kuranta->sekv);
	kuranta->tip = CIFER;
	kuranta->dat.cif = 0;
	while (kuranta1 != KKP)
	{
		arit_sumigi (kuranta, 1);
		kuranta1 = (kuranta1->dat.ref)->sekv;
	};
	return;
}


/* ========================================================================== */


/*
*	Функция "arit_sumigi" добавляет к натуральному числу, одним из разрядов
*	которого является "kuranta", число, получаемое перемножением числа "l"
*	и основания разряда "kuranta". Для корректной работы функции необходимо
*	выполнение неравенства l < 18446744069414584321.
*
*/

void
arit_sumigi (LITERO * kuranta, unsigned long long l)
{
	unsigned long long k;
	LITERO *kuranta1;

	kuranta1 = kuranta;
	k = l;
	do
	{
		k += kuranta1->dat.cif;
		kuranta1->dat.cif = (unsigned int) (k % 4294967296ULL);
		kuranta1 = kuranta1->sekv;
		k /= 4294967296ULL;
	}
	while ((k != 0) && !ESTAS_D_LIT_PARENT (kuranta1));
	if (k != 0)
	{
		krei_literon ((kuranta1->ant)->sekv);
		((kuranta1->ant)->sekv)->ant = kuranta1->ant;
		ligi_literojn ((kuranta1->ant)->sekv, kuranta1);
		kuranta1 = kuranta1->ant;
		kuranta1->tip = CIFER;
		kuranta1->dat.cif = (unsigned int) k;
	};
	return;
}


/*
*	Функция "arit_subtrahi" вычитает из натурального числа, одним из разрядов
*	которого является "kuranta", число, получаемое перемножением числа "l"
*	и основания разряда "kuranta".
*
*	ПРИМЕЧАНИЕ: 
*	1) вычитаемое число не должно превышать то, из которого оно вычитается;
*	2) 'лишние' нули в старших разрядах (если таковые возникают при вычитании)
*	не удаляются.
*
*/

void
arit_subtrahi (LITERO * kuranta, unsigned long long l)
{
	unsigned long long k, k1;
	LITERO *kuranta1;

	kuranta1 = kuranta;
	k = l;
	do
	{
		k1 = 4294967296ULL + kuranta1->dat.cif - (k % 4294967296ULL);
		kuranta1->dat.cif = (unsigned int) (k1 % 4294967296ULL);
		kuranta1 = kuranta1->sekv;
		k /= 4294967296ULL;
		if (k1 < 4294967296ULL)
		{
			k++;
		};
	}
	while (k != 0);
	return;
}
