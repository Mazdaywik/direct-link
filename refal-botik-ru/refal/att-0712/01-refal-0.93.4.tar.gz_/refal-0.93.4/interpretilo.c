/*
*	interpretilo.c - наиболее общие функции интерпретатора.
*	© 2005, А.А.Владимиров.
*
*	Данная программа является свободным программным обеспечением.
*	Вы вправе распространять ее и/или модифицировать в соответствии
*	с условиями версии 2, либо, по вашему выбору, с условиями
*	более поздней версии Стандартной Общественной Лицензии GNU,
*	опубликованной Free Software Foundation.
*
*	Мы распространяем данную программу в надежде на то, что она будет вам
*	полезной, однако НЕ ПРЕДОСТАВЛЯЕМ НА НЕЕ НИКАКИХ ГАРАНТИЙ, в том числе
*	ГАРАНТИИ ТОВАРНОГО СОСТОЯНИЯ ПРИ ПРОДАЖЕ и ПРИГОДНОСТИ ДЛЯ ИСПОЛЬЗОВАНИЯ
*	В КОНКРЕТНЫХ ЦЕЛЯХ. Для получения более подробной информации ознакомьтесь
*	со Стандартной Общественной Лицензией GNU.
*
*	Вместе с данной программой вы должны были получить экземпляр
*	Стандартной Общественной Лицензии GNU. Если вы его не получили,
*	сообщите об этом в
*	
*	Free Software Foundation, Inc.,
*	59 Temple Place, Suite 330,
*	Boston, MA 02111-1307
*	USA
*
*/

# include "refal.h"
# include <string.h>
# include <dlfcn.h>
# include <libintl.h>


unsigned int linnum = 0;
char *programo = NULL;


void interp_krei_masxinon (char *);
void interp_eraro (char);


char interp_legi_literon (FILE *, LITERO *);
LITERO *interp_legi (FILE *, char *);
char *interp_skribi (LITERO *);


/* ========================================================================== */


extern void interp_aldoni_funkcion (LITERO *);
extern void interp_aldoni_substituon (LITERO *);
extern LITERO *interp_preni_nomon (LITERO*, LITERO **);
extern LITERO *interp_preteriri_spacetojn (LITERO *);
extern char interp_kompari_nomojn (LITERO*, LITERO *);
extern void interp_detrui_funkcion (FUNKCIO *);
extern LITERO *interp_preni_linion (char *);


/* ========================================================================== */


/*
*	Функция "interp_krei_masxinon" конструирует набор функций рефал-машины,
*	описанный в файле с именем "titolo".
*
*/

void
interp_krei_masxinon (char *titolo)
{
	char i, j, *linio;
	unsigned int linnum_lok = 0;
	LITERO *kuranta, *nomo, *include, *use, *start;
	FILE *dosiero;

	include = interp_preni_linion ("include");
	use = interp_preni_linion ("use");
	start = interp_preni_linion ("start");
	dosiero = fopen (titolo, "r");
	if (dosiero == NULL)
	{
		interp_eraro (13);
	};
	programo = titolo;
	KFS = NULL;
	while (1)
	{
		linnum = linnum_lok;
		kuranta = interp_legi (dosiero, &i);
		linnum_lok = linnum;
		if (i)
		{
			if (kuranta != NULL)
			{
				switch (kuranta->dat.cif)
				{
/* комментарий */	case 35:
					while (kuranta->sekv != NULL)
					{
						kuranta = kuranta->sekv;
						detrui_literon (kuranta->ant);
					};
					detrui_literon (kuranta);
					break;

/* отступ */		case 9:
				case 32:
					kuranta = interp_preteriri_spacetojn (kuranta);
					if (kuranta != NULL)
					{
						if (KFS == NULL)
						{
							interp_eraro (6);
						};
						krei_literon (KFS->dat.ref);
						KFS = KFS->dat.ref;
						KFS->dat.ref = NULL;
						interp_aldoni_substituon (kuranta);
					};
					break;

/* $-директива */	case 36:
					if (kuranta->sekv == NULL)
					{
						interp_eraro (7);
					};
					kuranta = kuranta->sekv;
					detrui_literon (kuranta->ant);
					kuranta = interp_preni_nomon (kuranta, &nomo);
					j = 0;
					if (interp_kompari_nomojn (nomo, include))
					{
						j = 1;
					};
					if (interp_kompari_nomojn (nomo, use))
					{
						j = 2;
					};
					if (interp_kompari_nomojn (nomo, start))
					{
						j = 3;
					};
					while (nomo->sekv != NULL)
					{
						nomo = nomo->sekv;
						detrui_literon (nomo->ant);
					};
					detrui_literon (nomo);
					switch (j)
					{
					case 1:
						kuranta = interp_preteriri_spacetojn (kuranta);
						if (kuranta == NULL)
						{
							interp_eraro (7);
						};
						if ((kuranta->dat.cif != 39)
							|| (kuranta->sekv == NULL))
						{
							interp_eraro (7);
						};
						kuranta = kuranta->sekv;
						detrui_literon (kuranta->ant);
						nomo = kuranta;
						while ((kuranta->dat.cif != 39)
							&& (kuranta->sekv != NULL))
						{
							kuranta = kuranta->sekv;
						};
						if ((kuranta->dat.cif != 39) || (kuranta == nomo))
						{
							interp_eraro (7);
						};
						(kuranta->ant)->sekv = NULL;
						if (kuranta->sekv != NULL)
						{
							kuranta = kuranta->sekv;
							detrui_literon (kuranta->ant);
						}
						else
						{
							detrui_literon (kuranta);
							kuranta = NULL;
						};
						kuranta = interp_preteriri_spacetojn (kuranta);
						if (kuranta != NULL)
						{
							interp_eraro (7);
						};
						linio = interp_skribi (nomo);
						interp_krei_masxinon (linio);
						programo = titolo;
						free (linio);
						break;

					case 2:
						kuranta = interp_preteriri_spacetojn (kuranta);
						if (kuranta == NULL)
						{
							interp_eraro (7);
						};
						if ((kuranta->dat.cif != 39)
							|| (kuranta->sekv == NULL))
						{
							interp_eraro (7);
						};
						kuranta = kuranta->sekv;
						detrui_literon (kuranta->ant);
						nomo = kuranta;
						while ((kuranta->dat.cif != 39)
							&& (kuranta->sekv != NULL))
						{
							kuranta = kuranta->sekv;
						};
						if ((kuranta->dat.cif != 39) || (kuranta == nomo))
						{
							interp_eraro (7);
						};
						(kuranta->ant)->sekv = NULL;
						if (kuranta->sekv != NULL)
						{
							kuranta = kuranta->sekv;
							detrui_literon (kuranta->ant);
						}
						else
						{
							detrui_literon (kuranta);
							kuranta = NULL;
						};
						kuranta = interp_preteriri_spacetojn (kuranta);
						if (kuranta != NULL)
						{
							interp_eraro (7);
						};
						kuranta = interp_preni_linion (BIB_DOSIERUJO);
						nomo->ant = kuranta;
						while (kuranta->sekv != NULL)
						{
							kuranta = kuranta->sekv;
						};
						kuranta->sekv = nomo;
						nomo = nomo->ant;
						(kuranta->sekv)->ant = kuranta;
						linio = interp_skribi (nomo);
						dlopen (linio, RTLD_LAZY);
						free (linio);
						linio = dlerror ();
						if (linio != NULL)
						{
							fprintf (stderr, "%s\n", linio);
							exit (EXIT_FAILURE);
						};
						break;

					case 3:
						interp_detrui_funkcion (LF->sekv);
						krei_literon ((LF->sekv)->dat.s);
						KFS = (LF->sekv)->dat.s;
						KFS->dat.ref = NULL;
						kuranta = interp_preteriri_spacetojn (kuranta);
						if (kuranta == NULL)
						{
							krei_literon (kuranta);
							kuranta->sekv = NULL;
						}
						else
						{
							krei_literon (kuranta->ant);
							(kuranta->ant)->sekv = kuranta;
							kuranta = kuranta->ant;
						};
						kuranta->dat.cif = 61;
						interp_aldoni_substituon (kuranta);
						break;
					
					default:
						interp_eraro (7);
						break;
					};
					KFS = NULL;
					break;

				default:
					interp_aldoni_funkcion (kuranta);
					break;
				};
			};
		}
		else
		{
			while (include->sekv != NULL)
			{
				include = include->sekv;
				detrui_literon (include->ant);
			};
			detrui_literon (include);
			while (use->sekv != NULL)
			{
				use = use->sekv;
				detrui_literon (use->ant);
			};
			detrui_literon (use);
			while (start->sekv != NULL)
			{
				start = start->sekv;
				detrui_literon (start->ant);
			};
			detrui_literon (start);
			fclose (dosiero);
			programo = NULL;
			return;
		};
	};
	return;
}


/*
*	Функция "interp_eraro" генерирует сообщения об ошибках интерпретации.
*
*/

void
interp_eraro (char ern)
{

	switch (ern)
	{
	case 3:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("troa dekstra struktura parentezo"));
		break;

	case 4:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("troa maldekstra struktura aŭ funkcia parentezo"));
		break;

	case 5:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("troa dekstra funkcia parentezo"));
		break;

	case 6:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("sendeterminata funkcio"));
		break;

	case 7:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("malbona $-operatoro"));
		break;

	case 8:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("malbona sekvenco de UTF-8"));
		break;

	case 9:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("malbona nomo de objekto"));
		break;

	case 10:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("malbona determino de objekto"));
		break;

	case 11:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("kolizio de variabloj"));
		break;

	case 12:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("uzo sendeterminan variablon"));
		break;

	case 13:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("malbona dosiernomo"));
		break;

	default:
		fprintf (stderr, "\n%s %s, %s %d: %s.\n", gettext ("Dosiero"),
			programo, gettext ("linio"), linnum,
			gettext ("nerekonita eraro"));
		break;
	};
	exit (EXIT_FAILURE);
	return;
}


/* ========================================================================== */


/*
*	Функция "interp_legi_literon" считывает из файла "dosiero" записанную
*	в кодировке UTF-8 букву и записывает по адресу "lit->dat.cif" её номер
*	в таблице юникода.
*
*	В случае успеха считывания возвращается значение 1. Если же считывание
*	невозможно (например, вследствие окончания файла), возвращается значение 0.
*
*/

char
interp_legi_literon (FILE *dosiero, LITERO *lit)
{
	char c, k = 32;

	if (fscanf (dosiero, "%c", &c) == EOF)
	{
		lit->dat.cif = 0;
		return 0;
	};
	if (!(c >> 7))
	{
		lit->dat.cif = (unsigned int) c;
		return 1;
	};
	if ((c >> 6 == 2) || (c >> 1 == 127))
	{
		interp_eraro (8);
	};
	while (c & k)
	{
		k >>= 1;
	};
	k--;
	lit->dat.cif = (unsigned int) (c & k);
	k = (~k) << 2;
	while (k)
	{
		if (fscanf (dosiero, "%c", &c) == EOF)
		{
			interp_eraro (8);
		};
		if (c >> 6 != 2)
		{
			interp_eraro (8);
		};
		lit->dat.cif <<= 6;
		lit->dat.cif |= (unsigned int) (c & 63);
		k <<= 1;
	};
	return 1;
}


/*
*	Функция "interp_legi" считывает записанную в кодировке UTF-8 строку
*	из файла "dosiero". При этом признаком конца строки, в соответствии с
*	принятыми в UNIX соглашениями, считается символ "^J". Если
*	последний символ строки есть "\", то следующая строка рассматривается
*	как продолжение текущей и также считывается (при этом символ "\"
*	из исходной строки удаляется). Считанные строки записываются в виде
*	последовательности литер, каждая из которых содержит номер
*	соответствующей буквы. Возвращаемым значением является указатель
*	на первую литеру из вышеописанной последовательности (либо NULL,
*	если считанная строка пуста).
*	
*	В случае успеха считывания величине "(*c)" присваивается значение 1.
*	В случае, если считывание невозможно (например, вследствие окончания
*	файла), этой величине присваивается значение 0.
*
*/

LITERO
*interp_legi (FILE *dosiero, char *c)
{
	char i, j = 1;
	LITERO *kuranta, *unua;

	krei_literon (kuranta);
	i = interp_legi_literon (dosiero, kuranta);
	if (!i)
	{
		detrui_literon (kuranta);
		(*c) = 0;
		return NULL;
	};
	(*c) = 1;
	if (kuranta->dat.cif == 10)
	{
		detrui_literon (kuranta);
		linnum++;
		return NULL;
	};
	unua = kuranta;
	while (j)
	{
		do
		{
			krei_literon (kuranta->sekv);
			(kuranta->sekv)->ant = kuranta;
			kuranta = kuranta->sekv;
			i = interp_legi_literon (dosiero, kuranta);
		}
		while (i && (kuranta->dat.cif != 10));
		detrui_literon (kuranta);
		kuranta = kuranta->ant;
		linnum++;
		if (kuranta->dat.cif == 92)
		{
			if (kuranta == unua)
			{
				i = interp_legi_literon (dosiero, kuranta);
				if (!i)
				{
					detrui_literon (kuranta);
					return NULL;
				};
				if (kuranta->dat.cif == 10)
				{
					detrui_literon (kuranta);
					linnum++;
					return NULL;
				};
			}
			else
			{
				detrui_literon (kuranta);
				kuranta = kuranta->ant;
			};
		}
		else
		{
			kuranta->sekv = NULL;
			j = 0;
		};
	};
	return unua;
}


/*
*	Функция "interp_skribi" возвращает записанную в кодировке UTF-8 строку,
*	отвечающую непустой последовательности литер с началом "unua".
*	Сама последовательность литер при этом удаляется.
*
*/

char
*interp_skribi (LITERO *unua)
{
	char i = 1, *linio;
	unsigned int k = 1, c;
	LITERO *kuranta;
	
	kuranta = unua;
	while (kuranta != NULL)
	{
		c = kuranta->dat.cif;
		kuranta = kuranta->sekv;
		k++;
		if (c >> 7)
		{
			k++;
			if (c >> 11)
			{
				k++;
				if (c >> 16)
				{
					k++;
					if (c >> 21)
					{
						k++;
						if (c >> 26)
						{
							k++;
						};
					};
				};
			};
		};
	};
	linio = (char *) malloc (sizeof (char) * k);
	if (linio == NULL)
	{
		exit (EXIT_FAILURE);
	};
	kuranta = unua;
	k = 0;
	while (kuranta != NULL)
	{
		i = 0;
		c = kuranta->dat.cif;
		if (kuranta->sekv == NULL)
		{
			detrui_literon (kuranta);
			kuranta = NULL;
		}
		else
		{
			kuranta = kuranta->sekv;
			detrui_literon (kuranta->ant);
		};
		if (!(c >> 7))
		{
			linio[k] = (char) c;
			k++;
			i = 1;
		};
		if ((i == 0) && !(c >> 11))
		{
			linio[k] = (char) ((c >> 6) | 192);
			c <<= 26;
			k++;
			i = 2;
		};
		if ((i == 0) && !(c >> 16))
		{
			linio[k] = (char) ((c >> 12) | 224);
			c <<= 20;
			k++;
			i = 3;
		};
		if ((i == 0) && !(c >> 21))
		{
			linio[k] = (char) ((c >> 18) | 240);
			c <<= 14;
			k++;
			i = 4;
		};
		if ((i == 0) && !(c >> 26))
		{
			linio[k] = (char) ((c >> 24) | 248);
			c <<= 8;
			k++;
			i = 5;
		};
		if (i == 0)
		{
			linio[k] = (char) ((c >> 30) | 252);
			c <<= 2;
			k++;
			i = 6;
		};
		while (i != 1)
		{
			linio[k] = (char) ((c >> 26) | 128);
			c <<= 6;
			k++;
			i--;
		};
	};
	linio[k] = 0;
	return linio;
}
