/*
Select 	(en) e.Sets, e.Sets : \{
		= en;
		(e1 ta e2) e.Sets1, en: # e3 ta e4 , <Select (en ta) e.Sets1>;
		}

Ptime = <PRINTLN <TIME>>;

$ENTRY GO = <Do <ARG 2>>;
Do ea = <Ptime> <PRINTLN <Select () <MkArg ea>>> <Ptime>;

MkArg { 
	e1 sx = (e1 sx) <MkArg e1>;
	= ;
	};

Main {
	s1 = <Do <GETV s1>;
	e1 = <PRINTLN "Usage: Select abcdef...">;
}

*/

import refal.*;
/*
Select 	(en) e.Sets, e.Sets : \{
		= en;
		(e1 ta e2) e.Sets1, en: # e3 ta e4 , <Select (en ta) e.Sets1>;
		}
*/
public class Select {
	private String str1 = "Usage: Select abcdef...";
	static Object[] select (Object[] en, Object[] eSets) {
		if (eSets.length==0) return en;
		else {
			Object[] eSet; 
			eSet = Lang.cont(eSets[0]); // $fail, if not parentheses
			if (eSet == null) return null;		// $fail 
		L:	for(int i=0; i<eSet.length;i++) {
				Object ta = eSet[i];
				for (int j=0; j<en.length; j++) {
					if (ta.equals(en[j])) continue L;
				}
				Object[] eSets1 = Lang.drop(eSets,1);
				// en1 := en ta 
				Object[] en1 = new Object[en.length+1];
				System.arraycopy(en,0,en1,0,en.length);
				en1[en.length] = ta;
				// , <Select (e.n1) e.Sets1>
				Object[] res = select(en1, eSets1);
				if (res!=null) return res;
				continue L;
			}
			return null;
		}
	}
/*
MkArg { 
	e1 tx = (e1 tx) <MkArg e1>;
	= ;
	};
*/
	static Object[] mkArg(Object[] e0) {
		if (e0.length!=0) {
			Object tx = e0[e0.length-1];
			Object[] e1 = Lang.take(e0,e0.length-1);
			Object[] res = mkArg(e1);
			if (res==null) throw new Error("UnexpectedFail");
			Object[] out = new Object[res.length+1];
			out[0] = new Parenth(e0);
			System.arraycopy(res,0,out,1,res.length);
			return out;
		}
		else return new Object[0];
	}

// Execution test
	static double getTime() {
		return 0.001*System.currentTimeMillis();
	}

	static public void main(String[] args) throws java.io.IOException {
		System.out.println("Start");
		double t1 = getTime();
		Object[] res = select(new Object[0], mkArg(args));
		if (res == null) System.out.println("Fail!");
		else {
			for (int i=0; i<res.length; i++) {
				System.out.print(res[i]+" ");
			}
			System.out.println("Success!");
		}
		double t2 = getTime();
		System.out.println("End");
		System.out.println("Time = "+ (t2-t1));
		System.in.read();
	}

}