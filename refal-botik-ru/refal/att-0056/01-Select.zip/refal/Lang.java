package refal;

public class Lang {
    public static Object[] cont(Object t) {
		if (t instanceof Parenth)
			return ((Parenth)t).getCont();
		else return null;
	}

	public static Object[] drop(Object[] ex, int n) {
		if (n==0) return ex;
		else if (n>ex.length || n<0) throw new ArrayIndexOutOfBoundsException();
		else {
			Object[] res = new Object[ex.length-n];
			System.arraycopy(ex,n,res,0,ex.length-n);
			return res;
		}
	}

	public static Object[] take(Object[] ex, int n) {
		if (n>ex.length || n<0) throw new ArrayIndexOutOfBoundsException();
		else {
			Object[] res = new Object[n];
			System.arraycopy(ex,0,res,0,n);
			return res;
		}
	}
}
