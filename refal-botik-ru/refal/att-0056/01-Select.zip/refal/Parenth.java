package refal;
 public class Parenth {
    private Object[] cont;
    public Parenth(Object[] cont) {
        this.cont = cont;
    }
    public Object[] getCont() {
        return cont;
    }
 }
